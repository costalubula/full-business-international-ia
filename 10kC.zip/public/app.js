'use strict';
const P=window.FBI_PRODUITS,C=window.ERO7_CATALOGUE,WA='243823892361';
const chat=document.getElementById('chat'),input=document.getElementById('message');
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,"'").replace(/\s+/g,' ').trim();
const page=new URLSearchParams(location.search);let ctx=P.find(p=>p.slug===norm(page.get('article')||''))||null;let current=ctx, last='',lastModel='',lastPrice='',state=null,waiting=null;
function scroll(){chat.scrollTop=chat.scrollHeight}
function say(t,me=false){const d=document.createElement('div');d.className='bubble '+(me?'me':'bot');d.textContent=t;chat.append(d);scroll();return d}
function buttons(opts){const d=document.createElement('div');d.className='actionrow';for(const [label,fn,primary] of opts){let b=document.createElement('button');b.className='action'+(primary?' primary':'');b.type='button';b.textContent=label;b.addEventListener('click',fn);d.append(b)}chat.append(d);scroll()}
function link(label,url){let a=document.createElement('a');a.className='action primary';a.textContent=label;a.href=url;a.target='_blank';a.rel='noopener noreferrer';let d=document.createElement('div');d.className='actionrow';d.append(a);chat.append(d);scroll()}
function photo(p){if(!p||!p.photo){say('Nous n’avons pas de photo originale vérifiée pour cet article. Vous pouvez la demander à notre équipe.');buttons([['📲 Demander la photo originale',()=>handoff('Photo demandée : '+(p?.name||last))]]);return}const photos=[p.photo,...(p.photos||[])].filter((v,i,a)=>a.indexOf(v)===i).slice(0,4);for(const path of photos){let f=document.createElement('figure');f.className='photoCard';let im=document.createElement('img');im.src=path;im.alt='Photo d’origine : '+p.name;im.loading='lazy';let cap=document.createElement('figcaption');cap.textContent='Photo issue de notre fiche d’origine — '+p.name;f.append(im,cap);chat.append(f)}scroll()}
function wa(text){return 'https://wa.me/'+WA+'?text='+encodeURIComponent(text)}
function openDirect(url){window.open(url,'_blank','noopener,noreferrer')}
function handoff(question){const item=(current?current.name+' — ':'')+(lastModel?lastModel+' — ':'')+(question||last||'Article à préciser');say('Pour vous répondre avec précision, notre équipe doit vérifier cette demande. Le prix et la disponibilité ne sont pas confirmés automatiquement.');buttons([['📲 Envoyer ma demande sur WhatsApp',()=>openDirect(wa('📩 DEMANDE CLIENT — FULL BUSINESS INTERNATIONAL\n\n🔎 Article / question : '+item+'\n💰 Prix : à confirmer\n📦 Disponibilité : à confirmer\n\nBonjour, merci de me répondre.')),true]])}
function showSource(p){buttons([['📋 Fiche complète et commande',()=>openDirect(p.local)],['🌐 Voir le site de commande',()=>openDirect(p.url)],['📸 Photo réelle',()=>photo(p)],['🛒 Commander ici',()=>startOrder(p),true]])}
function intro(p,model=''){current=p;if(model)lastModel=model;let lines=p.details.map(x=>'• '+x).join('\n');say('📦 '+p.name.toUpperCase()+'\n\n'+lines+'\n\n📌 Prix et disponibilité définitifs à confirmer selon votre modèle.\n\n'+(p.id>=3&&!model?'Pour quel téléphone souhaitez-vous cette pochette ?':'Vous pouvez poser vos questions ou demander une commande.'));showSource(p)}
function addr(){say('📍 ETS ERO 7 BUSINESS — Galerie Dubaï Mall, Local C4, Avenue Ipenge N°1, Kinshasa-Gombe. Référence : Hôtel Memling, Boulevard du 30 Juin, en face de l’ex-Canon.\nÀ votre arrivée, demandez « Local C4 » à la sécurité.\n📞 +243 823 892 361.');}
function delivery(){say('🚚 Nous organisons la livraison directe à Kinshasa et, pour les commandes desservies depuis Lubumbashi, la livraison à Lubumbashi. La couverture dépend du produit et du service concerné.\n\n📦 Hors de la ville desservie, vous pouvez passer par un proche sur place ou choisir une agence d’expédition.\n\n💰 Les frais et modalités sont confirmés avant validation. Quelle est votre ville ?');}
// Prix reproduits de la fiche originale n° 03 (deux gammes distinctes).
const SMART_IC=[['S24 / S24+ / S24 Ultra',65],['S23 / S23+ / S23 Ultra',60],['S22 / S22+ / S22 Ultra',55],['S21 / S21+ / S21 Ultra',50],['S20 / S20+ / S20 Ultra',35],['S10 / S10+',30],['Note 10 / Note 10+',35],['Note 20 / Note 20 Ultra',40]];
const SMART_APP=[['S25 / S25+ / S25 FE / S25E',50],['S26 / S26+',50],['S25 Ultra / S26 Ultra',65],['S23 FE / S24 FE',40],['Z Fold 3 / 4 / 5 / 6 / 7 / 8 / 8 Ultra',45],['A16 / A17 / A36',25],['A55 / A56',30]];
function smartList(kind){
 const ic=kind!=='app',app=kind!=='ic';const parts=[];
 if(ic)parts.push('✅ IC — SANS APPLICATION\n'+SMART_IC.map(e=>'• '+e[0]+' : '+e[1]+' $').join('\n'));
 if(app)parts.push('📲 AVEC APPLICATION\n'+SMART_APP.map(e=>'• '+e[0]+' : '+e[1]+' $').join('\n'));
 say('📱 POCHETTES INTELLIGENTES SAMSUNG\n\n'+parts.join('\n\n')+'\n\n🧲 Fermeture magnétique et fonctions intelligentes selon la version. Les modèles avec application nécessitent une activation.\n\nQuel modèle Samsung avez-vous exactement ?');
 current=P[2];buttons([['📸 Voir la photo originale',()=>photo(P[2])],['🛒 Préparer ma commande',()=>startOrder(P[2]),true]]);return true;
}
function smartParse(raw){
 let t=understand(lingalaNormalize(raw)).replace(/\bgalaxy\b/g,' ').replace(/\bz\s*fold\b/g,'fold');
 let m=t.match(/\b(?:fold|zf)\s*([2-8])\s*(ultra)?\b/);if(m){let n=+m[1];return {model:'Z Fold '+n+(m[2]?' Ultra':''),price:n>=3?45:null,ic:false,available:n>=3};}
 m=t.match(/\bnote\s*(10|20)\s*(ultra|plus|\+)?\b/);if(m)return {model:'Note '+m[1]+(m[2]?' '+(m[2]==='plus'?'+':m[2]):''),price:m[1]==='10'?35:40,ic:true,available:true};
 m=t.match(/\ba\s*(16|17|36|55|56)\b/);if(m)return {model:'A'+m[1],price:['16','17','36'].includes(m[1])?25:30,ic:false,available:true};
 m=t.match(/\bs\s*(10|20|21|22|23|24|25|26)\s*(ultra|u|fe|plus|\+|e|edge)?\b/);
 if(m){const n=+m[1],v=m[2]||'',suffix=(v==='u'?'ultra':v==='plus'?'+':v);let price=null,ic=false;
  if(v==='fe'&&(n===23||n===24)){price=40;ic=false}
  else if(n===25||n===26){if(v==='ultra'||v==='u')price=65;else if(n===25&&['','+','plus','fe','e'].includes(v)||n===26&&['','+','plus'].includes(v))price=50;ic=false}
  else if([10,20,21,22,23,24].includes(n)&&['','ultra','u','+','plus'].includes(v)&&!(n===10&&(v==='ultra'||v==='u'))){price={10:30,20:35,21:50,22:55,23:60,24:65}[n];ic=true}
  return {model:'S'+n+(suffix?' '+suffix.toUpperCase():''),price,ic,available:price!=null};
 }
 return null;
}
function smartCaseAnswer(raw,force){
 const t=understand(lingalaNormalize(raw));const model=smartParse(raw);
 if(model){current=P[2];lastModel='Samsung '+model.model;lastPrice=model.price!=null?model.price+' $':'';
  if(!model.available){say('Merci 😊 Pour votre Samsung '+model.model+', nous n’avons pas de prix confirmé pour cette pochette intelligente. Je préfère vérifier avant de vous répondre.');buttons([['📲 Demander une vérification',()=>handoff('Pochette intelligente '+lastModel)],['📋 Voir les modèles publiés',()=>smartList('both')]]);return true}
  say('📱 POCHETTE INTELLIGENTE POUR '+lastModel.toUpperCase()+'\n\n💰 Prix publié : '+model.price+' $\n'+(model.ic?'✅ Version IC — SANS APPLICATION.':'📲 Version AVEC APPLICATION (activation nécessaire).')+'\n\n🧲 Fermeture magnétique, fonctions intelligentes selon le modèle.\n🎨 Couleur habituelle : noir, sous réserve de disponibilité.\n\nPour commander, nous vérifierons le modèle exact de votre téléphone et le stock.');
  buttons([['📸 Photo originale',()=>photo(P[2])],['📋 Lire la fiche complète',()=>openDirect(P[2].local)],['🛒 Commander cette pochette',()=>startOrder(P[2]),true]]);return true;
 }
 if(/\b(sans application|sans appli|\bic\b|certifie)\b/.test(t))return smartList('ic');
 if(/\b(avec application|avec appli|application|appli|qr code)\b/.test(t))return smartList('app');
 if(force||/\b(prix|tarif|liste|combien|modeles|disponible|intelligente|intelligent)\b/.test(t))return smartList('both');
 return false;
}

// Fiches accessoires : répondre au modèle exact sans inventer de compatibilité.
function caseModel(raw){
 const t=understand(lingalaNormalize(raw));let m=t.match(/\b(?:fold|zf)\s*([2-8])\s*(ultra)?\b/);
 if(m)return {family:'fold',n:+m[1],label:'Samsung Z Fold '+m[1]+(m[2]?' Ultra':'')};
 m=t.match(/\b(?:flip|zfl)\s*([2-7])\b/);if(m)return {family:'flip',n:+m[1],label:'Samsung Z Flip '+m[1]};
 m=t.match(/\biphone\s*(xr|1[1-8])\s*(pro\s*max|pro|max|plus|simple)?\b/);if(m)return {family:'iphone',n:m[1],variant:(m[2]||'').replace(/\s+/g,' '),label:'iPhone '+m[1]+(m[2]?' '+m[2]:'')};
 m=t.match(/\bs\s*(10|20|21|22|23|24|25|26)\s*(ultra|u|plus|\+|fe)?\b/);if(m)return {family:'samsung-s',n:+m[1],variant:m[2]||'',label:'Samsung S'+m[1]+(m[2]?' '+m[2]:'')};
 return null;
}
function caseProductAnswer(p,raw){
 if(!p||![4,5,6,7,8,9,10,11,12].includes(p.id))return false;
 const m=caseModel(raw);if(!m)return false;
 current=p;lastModel=m.label;let price=null,reason='',valid=false,info='';
 if(p.id===4){valid=m.family==='fold'&&m.n>=2&&m.n<=8;info='Rabat 30 $ sans stylet ou 35 $ avec stylet et anti-casse.'+(m.n===2?' ⚠️ Le rabat 30 $ pour Fold 2 n’a pas d’anti-casse intégré.':'')+' La version 2-en-1 MagSafe à 45 $ concerne Z Fold 3 à 7.'}
 if(p.id===5){valid=m.family==='fold'&&m.n>=3&&m.n<=7;price=35;info='Cuir et caoutchouc, stylet magnétique détachable et anti-casse.'}
 if(p.id===6){valid=m.family==='flip'&&m.n>=3&&m.n<=7;price=15;info='Pochette caoutchouc. Une version cuir à 20 $ est également indiquée, sous réserve de disponibilité.'}
 if(p.id===7){valid=['iphone','samsung-s'].includes(m.family);price=20;info='Rabat multifonction pour Samsung et iPhone, selon compatibilité de la référence.'}
 if(p.id===8){valid=(m.family==='fold'&&m.n>=3&&m.n<=7)||(m.family==='samsung-s'&&[24,25,26].includes(m.n)&&['ultra','u'].includes(m.variant))||(m.family==='iphone'&&+m.n>=14&&+m.n<=17&&m.variant==='pro max');price=m.family==='fold'?45:35;info='Modèle détachable avec MagSafe. Pour Z Fold : anti-casse intégré, sans stylet.'}
 if(p.id===9){valid=(m.family==='fold'||m.family==='flip')&&m.n>=2&&m.n<=7;price=m.family==='fold'?35:20;info='Pochette Design 119.'}
 if(p.id===10){valid=m.family==='iphone';price=15;info='Silicone MagSafe, sous réserve de compatibilité avec votre modèle exact.'}
 if(p.id===11){valid=m.family==='fold'&&m.n>=3&&m.n<=8;info='Fenêtre intelligente, sans anti-casse intégré. Prix publié à Kinshasa : 45 $. Pour les autres villes, tarif à confirmer.'}
 if(p.id===12){valid=m.family==='fold'&&m.n>=3&&m.n<=8;price=35;info='Caoutchouc MagSafe, anti-casse et stylet selon modèle. Couleurs : noir, bleu, gris et silver.'}
 if(!valid){say('Merci 😊 La fiche « '+p.name+' » ne confirme pas la compatibilité avec '+m.label+'. Je préfère éviter de vous proposer une pochette qui ne conviendrait pas.');buttons([['📋 Consulter la fiche',()=>openDirect(p.local)],['📲 Vérifier avec notre équipe',()=>handoff(p.name+' pour '+m.label)]]);return true}
 if(m.n===8&&m.family==='fold'&&[4,11,12].includes(p.id))info+=' ⚠️ Compatibilité Z Fold 8 / 8 Ultra à vérifier.';
 say('📱 '+p.name.toUpperCase()+'\n\n📲 Votre téléphone : '+m.label+'\n'+(price!=null?'💰 Prix publié : '+price+' $\n':'')+'\n'+info+'\n\n📦 Nous confirmerons la compatibilité exacte et le stock avant la commande.');
 if(price!=null)lastPrice=price+' $';buttons([['📸 Voir la photo',()=>photo(p)],['📋 Fiche détaillée',()=>openDirect(p.local)],['🛒 Préparer la commande',()=>startOrder(p),true]]);return true;
}

function priceInfo(p,raw){if(p.id===1)return phoneSearch(raw);if(p.id===3)return smartCaseAnswer(raw,false);
 if(p.id===4){let m=norm(raw).match(/\b(30|35|45)\s*\$?/);if(m){let d=m[1]==='30'?'rabat sans stylet':m[1]==='35'?'rabat avec stylet et anti-casse':'2-en-1 MagSafe sans stylet';say('📱 '+d+' : '+m[1]+' $.\nPour la version à 45 $, Z Fold 3 à 7 uniquement. La compatibilité du Z Fold 8 est à confirmer.');lastPrice=m[1]+' $';lastModel=raw;return true}}
 if(/prix|combien|tarif|coute|\$/.test(norm(raw))){say('💰 Informations publiées pour '+p.name+' :\n'+p.details.filter(x=>/\$|prix|tarif/i.test(x)).map(x=>'• '+x).join('\n')+'\n\nLe prix exact de votre variante et le stock doivent être confirmés.');return true}return false}
function phoneSearch(raw){const res=window.ERO7_MODEL_SEARCH.search(raw,C);if(/\b(?:iphone\s*)?(?:11|12|13|14|15|16|17|18)\s*(?:simple|normal|standard)\b/i.test(raw)&&res.missing){say('📱 Ce modèle simple n’a pas de prix confirmé dans les informations que nous avons reçues. Je préfère ne pas vous communiquer le prix d’une autre version.');handoff(raw);return true}if(!res.products.length){if(/telephone|samsung|iphone|pixel|tecno|infinix|itel|jbl|tablette/i.test(raw)&&!(/\d/.test(raw))){say('📱 Quel modèle exact recherchez-vous ? Par exemple « Samsung S24 Ultra » ou « iPhone 14 Pro Max ».');return true}handoff(raw);return true}
 current=P[0];let models=res.products.slice(0,10);let lines=[];if(res.missing)lines.push('ℹ️ '+res.missing);for(const p of models){let opts=p.options.map(o=>o.price!=null?o.storage+' : '+o.price+' $':o.storage+' : prix à confirmer');lines.push('📱 '+p.name+'\n'+opts.join('\n'));}if(res.products.length>10)lines.push('… '+(res.products.length-10)+' autres références. Précisez votre modèle pour affiner.');lines.push('\n📦 Stock et prix final à confirmer sur WhatsApp.');say(lines.join('\n\n'));if(models.length===1){lastModel=models[0].name;lastPrice='';}buttons([['📋 Fiche téléphones complète',()=>openDirect(P[0].local)],['🛒 Commander',()=>startOrder(P[0]),true],['ℹ️ Comment commander ?',()=>say('Choisissez votre modèle et sa capacité, puis appuyez sur Commander. Nous confirmerons le stock avant la vente.')]]);return true}
function findProduct(t){const s=norm(t);if(/smart\s*window|fenetre intelligente/.test(s))return P[10];if(/robot\s*(?:magsafe|mag safe)/.test(s))return P[11];if(/robot\s*(?:cf\s*1|design\s*cf\s*1)/.test(s))return P[4];if(/design\s*119/.test(s))return P[8];if(/(?:2\s*en\s*1|detachable)/.test(s))return P[7];if(/(?:rabat\s*multifonction|multifonction)/.test(s))return P[6];if(/(?:silicone\s*magsafe)/.test(s))return P[9];if(/(?:pochette|coque)\s*(?:en\s*)?caoutchouc.*flip|(?:z\s*)?flip.*caoutchouc/.test(s))return P[5];if(/(?:robot|pochette).*cf1/.test(s))return P[4];if(/(?:pochette|coque).*intelligent|intelligente\s*samsung|\bic\b/.test(s))return P[2];if(/(?:anti\s*-?\s*casse|hydrogel|privacy|protection\s*(?:d.ecran|ecran)|verre\s*trempe)/.test(s))return P[1];if(/(?:pochette|coque).*\b(?:z\s*)?fold|rabat.*fold/.test(s))return P[3];if(/\b(?:telephone|smartphone|iphone|pixel|tecno|infinix|itel|samsung\s+s\d|s\s*(?:9|10|20|21|22|23|24|25|26)\s*(?:ultra|\+|plus)?\b|z\s*fold|z\s*flip|jbl|tablette|tab\s*11|\ba\s*0?6\b)/.test(s))return P[0];return null}

// Reconnaissance locale de demandes courantes : fautes de frappe, abréviations,
// variantes d'écriture et contexte. Aucune IA distante, aucun prix inventé.
const vocab={
 'pochette':['pochete','pochet','poch','pochète','pochtte','pochettes','coque','coq','etui','étui','housse','cover','case','protection telephone'],
 'telephone':['tel','tél','téléph','teleph','telephone','phone','smartfone','smartphone','portable','appareil'],
 'iphone':['iphon','ipone','ifone','iph','aiphone','aifone','iphn','iphone'],
 'samsung':['samsong','samssung','samsun','samsg','sams','sam','galaxi','galaxy','samsung'],
 'fold':['zfold','z fold','zfod','zfol','zflod','zflod','fold','folde','folds','fold'],
 'flip':['zflip','z flip','zflp','flipp','flp','flip'],
 'intelligente':['inteligente','intelijente','inteligant','intelligent','intelligente','inteligente','intelligents','ic'],
 'magsafe':['mag safe','magsaf','magsef','magsafe','mag-saf'],
 'robot':['robo','robote','robot'],
 'rabat':['raba','rabba','rabat'],
 'anticasse':['anti casse','anticase','anti-cas','anticass','anti case','anticasse','anti-casse','film protecteur','protection ecran','protection écran','vitre','hydrogel','privacy','verre trempe'],
 'adresse':['adress','adrese','adres','adressse','localisation','localiser','localise','situé','situe','position'],
 'prix':['pri','prx','combien','tarif','coute','coûte','c combien','ca fait combien','ça fait combien'],
 'commander':['commandé','commade','comande','commander','acheter','achat','prendre'],
 'tecno':['techno','tekno','tecno'],
 'infinix':['infinx','infinnix','infinix'],
 'itel':['itel','itell'],
 'pixel':['pixle','pixl','pixel'],
 'ultra':['ultr','ultra','ultraa'],
 'pro':['pr0','pro'],
 'plus':['pluss','plus'],
 'ecouteurs':['ecouteur','ecouteurs','écouteurs','earpods','airpods','oreillettes','casque','headphone'],
 'accessoires':['accessoir','accesoire','accessoires','accessoire','chargeur','cable','usb','powerbank','power bank','batterie externe','support telephone','stylet'],
 'tablette':['tablete','tablète','tablette','ipad','tab'],
 'jbl':['jbl','boombox','charge 6','enceinte','baffle','haut parleur']
};
function simplify(t){return norm(t).replace(/[^a-z0-9+ ]/g,' ').replace(/\s+/g,' ').trim()}
const aliases=[];for(const [canonical,arr] of Object.entries(vocab))for(const a of arr){aliases.push([simplify(a),canonical])}
aliases.sort((a,b)=>b[0].length-a[0].length);
function dist(a,b){if(a===b)return 0;let x=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let n=[i];for(let j=1;j<=b.length;j++)n[j]=Math.min(n[j-1]+1,x[j]+1,x[j-1]+(a[i-1]!==b[j-1]));x=n}return x[b.length]}
function understand(raw){
 let t=simplify(raw).replace(/\b(z\s*fold|z\s*flip)\s*(\d)/g,(_,a,n)=>a.replace(/\s/g,'')+' '+n)
   .replace(/\b(s\s*)(2[0-6]|10|9)\b/g,'s$2')
   .replace(/\b(iph(?:one)?|ipone|ifone)\s*(1[0-8]|xr)\b/g,'iphone $2');
 // Corriger d'abord les expressions connues ; ne pas changer les nombres.
 for(const [a,c] of aliases){if(a===c||a.length<3)continue;let re=new RegExp('(^|\\s)'+a.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?=\\s|$)','g');t=t.replace(re,(_,prefix)=>prefix+c)}
 let words=t.split(' '), dictionary=['pochette','telephone','iphone','samsung','fold','flip','intelligente','magsafe','robot','rabat','anticasse','adresse','prix','commander','tecno','infinix','itel','pixel','ultra','ecouteurs','accessoires','tablette','jbl','hydrogel','stylet','chargeur','coque','disponible','livraison'];
 words=words.map(w=>{if(w.length<4||/\d/.test(w)||dictionary.includes(w))return w;let candidates=dictionary.map(d=>[d,dist(w,d)]).filter(([d,k])=>k<=(w.length<=5?1:2)&&Math.abs(w.length-d.length)<=2).sort((a,b)=>a[1]-b[1]);return candidates.length===1||candidates.length>1&&candidates[0][1]<candidates[1][1]?candidates[0][0]:w});
 t=words.join(' ').replace(/\b(zfold|zflip)\b/g,(_,a)=>a==='zfold'?'fold':'flip');
 // Z Fold 2, zf2, fold2 et Fold 2 -> même modèle.
 t=t.replace(/\b(?:zf|zfd|f0ld|fold)\s*([2-8])\b/g,'fold $1').replace(/\b(?:zfl|zflip|flip)\s*([2-7])\b/g,'flip $1');
 return t;
}
function foldNumber(t){let m=t.match(/\bfold\s*([2-8])\b/);return m?Number(m[1]):null}
function foldList(t){
 const n=foldNumber(t);const entries=[
  [P[3],'Rabat : 30 $ sans stylet ; 35 $ avec stylet et anti-casse',2,8],
  [P[8],'Design 119 : 35 $',2,7],
  [P[4],'Robot CF1 : 35 $',3,7],
  [P[11],'Robot MagSafe : 35 $',3,7],
  [P[7],'2-en-1 MagSafe : 45 $',3,7],
  [P[2],'Intelligente AVEC APPLICATION : 45 $',3,8],
  [P[10],'Smart Window : 45 $ à Kinshasa ; ailleurs à confirmer',3,8]
 ];
 const chosen=entries.filter(e=>!n||(n>=e[2]&&n<=e[3]));
 const lines=chosen.map((e,i)=>(i+1)+'. '+e[0].name+'\n   '+e[1]+(n===8?' (compatibilité à vérifier)':''));
 say('📱 '+(n?'Pour votre Samsung Z Fold '+n:'Pour les Samsung Z Fold')+', voici les pochettes figurant dans nos fiches :\n\n'+lines.join('\n\n')+'\n\n'+(n===2?'⚠️ Pour Z Fold 2, le rabat à 30 $ n’a pas d’anti-casse intégré.\n\n':'')+(n===8?'⚠️ La compatibilité Z Fold 8 / 8 Ultra doit être vérifiée.\n\n':'')+(n?'Laquelle vous intéresse ?':'Quel Z Fold avez-vous exactement ?'));
 current=P[3];lastModel=n?'Samsung Z Fold '+n:'';
 buttons(chosen.map(e=>['📱 '+e[0].name,()=>{current=e[0];if(e[0].id===3){smartCaseAnswer('z fold '+(n||''),true)}else intro(e[0],lastModel)}]));return true;
}
function ambiguousNumber(t){let m=t.match(/^(?:je cherche|je veux|je veux un|vous avez|un|le|pour|prix|combien|oh non|oh|non|svp|stp|c est|cest|c|un telephone|telephone|iphone)?\s*(1[1-8]|xr)\s*(?:svp|stp)?$/);return m?m[1]:null}
function interpret(raw){
 const t=understand(raw);
 // La question sur l'adresse peut être très courte ou familière.
 if(/\b(vous etes ou|vous ete ou|vous etez ou|vous etes situe|vous etes situe ou|c est ou|cest ou|ou se trouve|ou est votre|vous etes vers ou|vous etes dans quel coin|adresse|localisation|ou vous etes|votre position|vous etes a quel endroit|ou est le shop|boutique se trouve ou)\b/.test(t)){addr();return true}
 if(/\b(bonjour|salut|bjr|bsr|bonsoir)\b/.test(t)&&t.split(' ').length<=2){say('Salut 👋🏾 Vous souhaitez acheter quel article, s’il vous plaît ?');return true}
 const num=ambiguousNumber(t);if(num){say('D’accord 😊 Vous parlez de l’iPhone '+num+' ?\n\nVous cherchez :\n1️⃣ Le téléphone\n2️⃣ Une pochette pour iPhone '+num+'\n3️⃣ Un anti-casse pour iPhone '+num+'\n\nDites-moi simplement ce qui vous intéresse.');waiting={kind:'iphone',number:num};return true}
 if(waiting?.kind==='iphone'){
  if(/\b(telephone|iphone|appareil|1)\b/.test(t)){let num=waiting.number;waiting=null;return phoneSearch('iphone '+num)}
  if(/\b(pochette|coque|2)\b/.test(t)){let num=waiting.number;waiting=null;lastModel='iPhone '+num;say('📱 D’accord, vous cherchez une pochette pour iPhone '+num+'.\nQuel type de pochette souhaitez-vous : silicone MagSafe, rabat multifonction ou 2-en-1 MagSafe ?\nJe vérifierai ensuite la compatibilité avec votre modèle exact.');buttons([[P[9].name,()=>intro(P[9],lastModel)],[P[6].name,()=>intro(P[6],lastModel)],[P[7].name,()=>intro(P[7],lastModel)]]);return true}
  if(/\b(anticasse|protection|3)\b/.test(t)){let num=waiting.number;waiting=null;lastModel='iPhone '+num;intro(P[1],lastModel);return true}
 }
 // Demandes intelligentes, avec application et IC, même sans le mot « pochette ».
 if(/\b(intelligente|intelligent|\bic\b|avec application|sans application|smart cover)\b/.test(t)&&!(/\b(smart window)\b/.test(t))){return smartCaseAnswer(t,true)}
 // Une référence d'accessoire prime sur le numéro du téléphone cité.
 if(/\b(robot|design\s*119|smart\s*window|fenetre intelligente|2\s*en\s*1|rabat|silicone|magsafe|mag safe)\b/.test(t)){
  const p=findProduct(t);if(p&&p.id!==1){if(caseProductAnswer(p,t))return true;intro(p);return true}
 }
 // Les mots liés aux pochettes l'emportent sur la recherche de téléphones.
 const isCase=/\b(pochette|coque|etui|housse|cover|case)\b/.test(t);
 const isFold=/\bfold\b/.test(t), isFlip=/\bflip\b/.test(t);
 const isScreen=/\b(anticasse|hydrogel|privacy|verre trempe|film protecteur)\b/.test(t);
 const isPhone=/\b(telephone|smartphone|iphone|samsung|tecno|infinix|itel|pixel|galaxy|fold|flip)\b/.test(t);
 if(isCase&&isFold&&!/\b(robot|magsafe|intelligente|rabat|design|smart window|2 en 1|multifonction)\b/.test(t))return foldList(t);
 if(isCase&&isFlip&&!/\b(design|silicone|robot|magsafe|intelligente)\b/.test(t)){const m=t.match(/\bflip\s*([2-7])\b/);let n=m?Number(m[1]):null;lastModel=n?'Samsung Z Flip '+n:'';say('📱 Pour '+(n?'votre Z Flip '+n:'Samsung Z Flip')+', voici les pochettes mentionnées :\n\n'+(n===2?'• Design 119 : 20 $ (Z Flip 2 à 7)':'• Pochette caoutchouc : 15 $ (Z Flip 3 à 7)\n• Pochette cuir : 20 $ (Z Flip 3 à 7)\n• Design 119 : 20 $ (Z Flip 2 à 7)')+'\n\n'+(n?'Quelle pochette souhaitez-vous ?':'Quel Z Flip avez-vous exactement ?'));buttons((n===2?[[P[8].name,()=>intro(P[8],lastModel)]]:[[P[5].name,()=>intro(P[5],lastModel)],[P[8].name,()=>intro(P[8],lastModel)]]));return true}
 if(isCase&&!isFold&&!isFlip&&!/\b(robot|magsafe|intelligente|rabat|design|smart window|2 en 1|multifonction|silicone)\b/.test(t)){
   let device=t.match(/\b(?:iphone\s*(?:xr|1[1-8])|s\s*(?:9|10|2[0-6])|note\s*(?:10|20)|a\s*\d{2})\b/);
   if(device){lastModel=device[0];say('D’accord 😊 Vous cherchez une pochette pour '+device[0].toUpperCase()+'.\nQuel type de pochette recherchez-vous ? Nous vérifierons la compatibilité avec le modèle exact.');return true}
   say('Avec plaisir 😊 Pour bien vous orienter, quel téléphone avez-vous exactement ?\nExemple : Samsung Z Fold 4, S24 Ultra ou iPhone 14 Pro Max.');waiting={kind:'case'};return true;
 }
 if(waiting?.kind==='case'&&(isFold||isFlip)){waiting=null;return isFold?foldList(t):interpret('pochette '+t)}
 if(waiting?.kind==='case'&&caseModel(t)){waiting=null;const m=caseModel(t);lastModel=m.label;say('Merci 😊 Vous cherchez une pochette pour '+m.label+'.\nQuel type de pochette souhaitez-vous ? Vous pouvez préciser silicone MagSafe, rabat multifonction, intelligente Samsung ou autre modèle. Nous vérifierons la compatibilité exacte.');return true}
 if(isScreen&&/\b(iphone|samsung|fold|flip|s\d+|pixel|tecno|infinix)\b/.test(t)){lastModel=t;intro(P[1],lastModel);return true}
 if(/\b(ecouteurs|accessoires|jbl|tablette|chargeur|powerbank)\b/.test(t)){
   if(/\bjbl\b/.test(t)){return phoneSearch(t)}
   say('D’accord 😊 Quel est le nom ou le modèle exact de l’accessoire que vous cherchez ?\nJe vérifierai les informations disponibles. Si le prix ou le stock n’est pas indiqué, notre équipe pourra vous répondre sur WhatsApp.');return true;
 }
 // Les références saisies seules après une question sur la pochette restent dans ce contexte.
 if(current&&current.id!==1&&(/\bfold\s*[2-8]\b|\bflip\s*[2-7]\b|\biphone\s*(?:xr|1[1-8])\b|\bs\s*(?:9|10|2[0-6])\b/.test(t))&&!/\b(telephone|acheter telephone|smartphone)\b/.test(t)){
  lastModel=t;
  if(current.id===3&&/\bfold\s*[2-8]\b/.test(t)){say('📱 Merci. Pour la pochette intelligente de ce Z Fold, la version, l’activation et le prix doivent être vérifiés. Voulez-vous consulter sa fiche ou demander une confirmation ?');showSource(current);return true}
  if(current.id===4&&/\bfold\s*[2-8]\b/.test(t))return foldList('pochette '+t);
  if(current.id===3&&priceInfo(current,t))return true;
  if(caseProductAnswer(current,raw))return true;
  say('📱 Merci, vous avez indiqué : '+t.toUpperCase()+'.\n\n'+current.details.map(x=>'• '+x).join('\n')+'\n\n📌 Compatibilité et stock à confirmer pour votre modèle.');showSource(current);return true;
 }
 // Recherche de téléphone avec orthographe réparée.
 if(isPhone&&!isCase&&!isScreen){const r=window.ERO7_MODEL_SEARCH.search(t,C);if(r.products.length||/\b(?:iphone|samsung|pixel|tecno|infinix|itel|fold|flip)\b/.test(t))return phoneSearch(t)}
 if(t!==simplify(raw)){
  const found=findProduct(t);
  if(found){if(found.id===1)return phoneSearch(t);intro(found);return true}
 }
 return false;
}


// V6 : expressions de Kinshasa, français familier, quelques phrases lingala,
// objection prix et arguments fondés UNIQUEMENT sur les caractéristiques publiées.
function lingalaNormalize(raw){
 let t=norm(raw).replace(/[?!.,;:]/g,' ').replace(/\s+/g,' ').trim();
 const rules=[
  [/\b(bozali wapi|boza wapi|bozala wapi|bozali na wapi|shop ezali wapi|esika nini|esika bozali|adresse na bino|bozali na adresse nini)\b/g,' vous etes ou '],
  [/\b(eza combien|ezali combien|mbongo boni|talo nini|talo boni|prix na yango|eza talo nini|eza boni)\b/g,' combien prix '],
  [/\b(nalingi kosomba|nalingi na somba|na lingi kosomba|nalingi na zwa|nalingi kozua|na sombi)\b/g,' je veux acheter '],
  [/\b(nazali koluka|nazoluka|nazo luka|na luka|nalingi)\b/g,' je cherche '],
  [/\b(bozali na|boza na|bozali na yango|bozali na stock)\b/g,' vous avez '],
  [/\b(ezali disponible|eza disponible|eza na stock|boza na stock|ezali nanu|eza nanu)\b/g,' disponible '],
  [/\b(bo memaka|bomemaka|bo livraka|botindaka|bokotinda|botindaka na)\b/g,' livraison '],
  [/\b(eza cher|ezali cher|talo eleki|kitisa prix|kitisa talo|prix ekita|talo mingi)\b/g,' trop cher '],
  [/\b(nazali na|naza na|na zali na)\b/g,' j ai '],
  [/\b(pochette ya|coque ya|protection ya)\b/g,' pochette '],
  [/\b(anticasse ya|anti casse ya)\b/g,' anticasse '],
  [/\b(merci mingi|matondi mingi|matondi)\b/g,' merci '],
  [/\b(boni|mbote na bino|mbote)\b/g,' salut '],
  [/\b(oyo|wana|yango)\b/g,' ']
 ];for(const [re,v] of rules)t=t.replace(re,v);
 return t.replace(/\s+/g,' ').trim();
}
function persuasiveReply(t){
 const p=current;
 if(!p){say('Avec plaisir 😊 Dites-moi simplement quel article vous intéresse, et je vous donnerai les informations que nous avons sur ce modèle.');return}
 const name=p.name, benefits=p.details.filter(x=>!(/\$/.test(x)||/prix|stock|disponibilit|confirmer|couleur|horaire/i.test(x))).slice(0,3);
 const benefitsText=benefits.length?benefits.map(x=>'• '+x).join('\n'):'Je peux vous expliquer les caractéristiques mentionnées dans sa fiche.';
 if(/trop cher|negoci|remise|reduction|rabais|dernier prix|faire prix|moins cher|cher pour moi/.test(t)){
   say('Je comprends tout à fait 😊\n\nPour '+name+', voici ce qui est indiqué dans notre fiche :\n'+benefitsText+'\n\nSi le prix ne vous convient pas, vous pouvez proposer votre budget. Nous transmettrons votre proposition au responsable, sans promettre une réduction.');
   buttons([['💬 Faire une proposition',()=>{waiting={kind:'offer',product:name};say('Quel prix souhaitez-vous proposer pour '+name+' ? Je le transmettrai à notre équipe pour examen.')}],['📋 Relire la fiche',()=>intro(p)]]);return;
 }
 if(/hesite|reflech|revenir|plus tard|je vais voir|je compare|pas sur|c est bon|je sais pas|je ne sais pas/.test(t)){
   say('Aucun souci, prenez le temps de choisir 😊\n\nPour '+name+', les points importants sont :\n'+benefitsText+'\n\nQuel point souhaitez-vous vérifier : la compatibilité, la protection, le prix ou la livraison ?');return;
 }
 if(/qualite|solide|resistant|protege|avantage|interet|pourquoi|difference|c est quoi|ca sert|c est bien|c est bon|est ce fiable/.test(t)){
   say('Bonne question 😊 Voici les caractéristiques annoncées pour '+name+' :\n\n'+p.details.map(x=>'• '+x).join('\n')+'\n\nJe préfère confirmer la compatibilité et la disponibilité avant votre achat. Quel modèle exact de téléphone avez-vous ?');return;
 }
 if(/comment choisir|lequel choisir|quelle version|me conseille|conseil|recommand/.test(t)){
   say('Je peux vous aider à choisir 😊 Pour éviter une erreur de modèle, dites-moi d’abord quel téléphone vous utilisez exactement. Ensuite, nous comparerons seulement les versions prévues pour cet appareil.');return;
 }
}
function conversationalHelp(raw){
 const t=understand(lingalaNormalize(raw));
 if(waiting?.kind==='offer'){
  if(/\b(?:annuler|non|stop)\b/.test(t)){waiting=null;say('D’accord 😊 Nous restons disponibles si vous avez une autre question.');return true}
  const proposal=raw.trim();const item=waiting.product;waiting=null;
  say('Merci 😊 Votre proposition pour '+item+' sera examinée par notre responsable. Aucune remise n’est confirmée pour le moment.');
  buttons([['📲 Transmettre ma proposition',()=>openDirect(wa('💬 PROPOSITION DE PRIX — FULL BUSINESS INTERNATIONAL\n\n📦 Article : '+item+'\n💰 Proposition du client : '+proposal+'\n📌 Accord et disponibilité : à confirmer.\n\nBonjour, merci d’examiner ma proposition.')),true]]);return true;
 }
 if(/\b(vous etes ou|esika nini|ou se trouve|vous etes situe|adresse|ou est le shop|ou se trouve votre boutique)\b/.test(t)){addr();return true}
 if(/\b(trop cher|cher pour moi|talo mingi|kitisa|negoci|dernier prix|remise|reduction|rabais|faire prix)\b/.test(t)){
  if(current)persuasiveReply('trop cher');else say('Je comprends 😊 Quel article et quel modèle souhaitez-vous ? Je vous donnerai d’abord le prix publié, puis vous pourrez faire une proposition si vous le souhaitez.');return true;
 }
 if(/\b(hesite|reflech|revenir|plus tard|je vais voir|je compare|pas sur|je sais pas|je ne sais pas|qualite|solide|resistant|protege|avantage|interet|pourquoi|difference|c est quoi|ca sert|est ce fiable|comment choisir|lequel choisir|quelle version|me conseille|conseil|recommand)\b/.test(t)&&current){persuasiveReply(t);return true}
 if(current&&/^(?:je prends|je le prends|je veux le prendre|je veux acheter|c est bon je prends|ok je prends|je commande|je veux commander|nalingi kosomba)(?: svp)?$/.test(t)){startOrder(current);return true}
 if(/\b(merci|matondi|matondi mingi)\b/.test(t)&&t.split(' ').length<=4){say('Avec plaisir 😊 Si vous avez une question sur votre article, je vous écoute.');return true}
 if(/\b(bo memaka|livraison|livrer|expedition|envoyer en province)\b/.test(t)&&!/\b(?:pochette|telephone|iphone|fold|flip)\b/.test(t)){delivery();return true}
 // Ask for model on generic pouch query, never silently assume a model.
 if(/^(?:je cherche|je veux|vous avez|j ai besoin de|nalingi|pochette)?\s*(?:une |des |la )?(?:pochette|coque|etui|housse|cover)s?\s*(?:svp|stp)?$/.test(t)){
   waiting={kind:'case'};say('Bien sûr 😊 Pour quel téléphone cherchez-vous une pochette ? Écrivez le modèle exact, par exemple Z Fold 2, S24 Ultra ou iPhone 14.');return true;
 }
 // Questions de prix en lingala, sans modèle : demander le produit.
 if(/^(?:combien prix|prix combien|prix prix|prix|combien|talo nini|mbongo boni)(?: svp)?$/.test(t)&&!current){say('Avec plaisir 😊 De quel article souhaitez-vous connaître le prix ?');return true}
 if(/\b(je cherche|je veux acheter|vous avez)\b/.test(t)&&/\b(pochette|fold|flip|iphone|samsung|anticasse|hydrogel|pixel|tecno|infinix|itel)\b/.test(t)&&lingalaNormalize(raw)!==norm(raw)){
   return interpret(t);
 }
 return false;
}

function startOrder(p){current=p;state=null;openRequestForm(p.id===2?'reservation':'commande',p)}
function startTrade(){current=P[0];state=null;say('🔄 Le troc et la contre-valeur sont évalués uniquement à notre établissement. Aucun montant n’est fixé par message.');openRequestForm('troc',P[0])}
function answerForm(raw){const v=raw.trim(),step=state.step;if(!v)return;
 if(step==='model'){state.model=v;lastModel=v;if(state.kind==='reservation'){state.step='date';say('Quel jour souhaitez-vous passer ? (Lundi au samedi, de 9 h à 17 h.)');return}if(state.kind==='troc'){state.step='desired';say('Quel téléphone souhaitez-vous obtenir en échange ?');return}if(current.id===1){state.step='storage';say('Quelle capacité de stockage souhaitez-vous ? (Ex. : 256 Go ; si sans objet, écrivez « sans objet ».)');return}if(current.id===4){state.step='variant';say('Quelle version de pochette souhaitez-vous : 30 $, 35 $ ou 45 $ ?');return}if(current.id!==3){state.step='quantity';say('Quelle quantité souhaitez-vous commander ?');return}state.step='quantity';say('Quelle quantité souhaitez-vous commander ? (Ex. : 1)');return}
 if(step==='storage'){state.storage=v;state.step='quantity';say('Quelle quantité souhaitez-vous commander ?');return}
 if(step==='variant'){const m=v.match(/(?:30|35|45)/);if(!m){say('Précisez la version 30 $, 35 $ ou 45 $.');return}if(m[0]==='45'&&/fold\s*2\b/i.test(state.model)){say('La version à 45 $ ne figure pas pour Z Fold 2. Choisissez 30 $ ou 35 $.');return}state.variant=m[0]+' $';state.price=state.variant;state.step='quantity';say('Quelle quantité souhaitez-vous commander ?');return}
 
 if(step==='desired'){state.desired=v;state.step='date';say('Quel jour souhaitez-vous passer à notre établissement ?');return}
 if(step==='quantity'){if(!/^\d{1,3}$/.test(v)||+v<1){say('Veuillez indiquer une quantité, par exemple 1.');return}state.quantity=v;state.step='city';say('Dans quelle ville êtes-vous ?');return}
 if(step==='city'){state.city=v;state.step='commune';say('Quelle est votre commune ou votre quartier ?');return}
 if(step==='commune'){state.commune=v;state.step='address';say('Quelle est votre adresse ou le point de retrait souhaité ?');return}
 if(step==='address'){state.address=v;state.step='name';say('Quel nom devons-nous inscrire sur votre demande ?');return}
 if(step==='date'){state.date=v;state.step='hour';say('À quelle heure souhaitez-vous venir ? (La réservation reste à confirmer.)');return}
 if(step==='hour'){state.hour=v;state.step='name';say('Quel nom devons-nous inscrire sur la réservation ?');return}
 if(step==='name'){state.name=v;state.step='phone';say('Quel numéro de téléphone pouvons-nous utiliser pour vous répondre ?');return}
 if(step==='phone'){if(v.replace(/\D/g,'').length<9){say('Merci de préciser un numéro valide.');return}state.phone=v;state.step='confirm';const summary=summaryText();say('📋 RÉCAPITULATIF — À VÉRIFIER\n\n'+summary+'\n\nLe prix, la disponibilité et les modalités restent soumis à confirmation.\n\nAppuyez sur le bouton pour ouvrir WhatsApp, puis ENVOYEZ le message.');buttons([['📲 Envoyer sur WhatsApp',()=>openDirect(wa('📩 FULL BUSINESS INTERNATIONAL\n\n'+summary+'\n\nMerci de confirmer la disponibilité, le prix et les modalités.')),true],['✏️ Recommencer',()=>startOrder(current)]]);return}
 if(step==='confirm'){say('Votre demande n’a pas encore été envoyée. Utilisez le bouton WhatsApp du récapitulatif pour la transmettre à notre équipe.');return}}
function summaryText(){const s=state;return ['Type : '+s.kind,'Article : '+s.article,'Modèle / référence : '+s.model,s.desired?'Téléphone souhaité : '+s.desired:'',s.quantity?'Quantité : '+s.quantity:'',s.storage?'Stockage : '+s.storage:'',s.variant?'Version : '+s.variant:'',s.color?'Couleur souhaitée : '+s.color:'',s.price?'Prix affiché : '+s.price:'',s.city?'Ville : '+s.city:'',s.commune?'Commune / quartier : '+s.commune:'',s.address?'Adresse : '+s.address:'',s.date?'Date souhaitée : '+s.date:'',s.hour?'Heure souhaitée : '+s.hour:'','Nom : '+s.name,'Téléphone : '+s.phone,'Disponibilité : à confirmer','Frais de livraison : à confirmer',s.kind==='commande'&&current?.id>=3?'Merci de joindre une capture « À propos du téléphone » pour confirmer la compatibilité.':''].filter(Boolean).join('\n')}
function process(raw){const t=norm(raw);last=raw;if(handlePriority(raw))return;if(state){if(/^(annuler|stop|quitter|recommencer)$/.test(t)){state=null;say('D’accord, la saisie a été interrompue. Quel article recherchez-vous ?');return}answerForm(raw);return}
 if(conversationalHelp(raw))return;
 const adapted=lingalaNormalize(raw);
 if(adapted!==norm(raw)&&interpret(adapted))return;
 if(interpret(raw))return;
 if(/\b(adresse|local c4|memling|ou (etes|est) votre (boutique|magasin)|ou vous trouvez|localisation)\b/.test(t)){addr();return}
 if(/\b(livrai\w*|expedi\w*|transport|autre ville|province|kinshasa|lubumbashi)\b/.test(t)&&!/(?:pochette|telephone|prix|modele)/.test(t)){delivery();return}
 if(/\b(troc|contre.?valeur|echange de telephone)\b/.test(t)){say('🔄 Troc et contre-valeur : évaluation uniquement sur place, Galerie Dubaï Mall, Local C4. Aucun montant n’est fixé par message.');buttons([['🗓️ Demander un rendez-vous',startTrade,true]]);return}
 if(/\b(disponib\w*|en stock|reste|encore disponible|stock)\b/.test(t)){say('📦 Je peux vous donner les caractéristiques et le prix publié, mais le stock doit être vérifié pour votre modèle exact. Si vous souhaitez acheter, nous pouvons préparer votre demande ici. 😊');buttons([['🛒 Préparer ma commande',()=>current?startOrder(current):say('Quel article souhaitez-vous commander ?'),true],['📲 Vérifier le stock',()=>handoff(raw)]]);return}
 if(/\b(trop cher|moins cher|reduction|remise|negocier|dernier prix)\b/.test(t)){say('💬 Vous pouvez proposer un prix. Notre équipe examinera votre proposition ; aucune remise n’est acceptée automatiquement.');buttons([['📲 Envoyer ma proposition',()=>handoff('Proposition de prix : '+raw),true]]);return}
 if(/\b(photo|image|voir le produit|montre.*photo)\b/.test(t)){if(current)photo(current);else say('Quel article souhaitez-vous voir ? Je montrerai uniquement une photo issue de nos fiches originales.');return}
 if(/\b(comment commander|comment acheter|je veux commander|je commande|passer commande|commander maintenant|je vais acheter|reserver|reservation)\b/.test(t)){if(!current){const specific=findProduct(raw);if(specific){current=specific;intro(specific);return}say('Quel article souhaitez-vous commander ou réserver ?');return}startOrder(current);return}
 if(/\b(fiche|lien|site|catalogue complet)\b/.test(t)){if(current){say('Voici la fiche d’origine de '+current.name+'.');showSource(current)}else say('Précisez d’abord l’article qui vous intéresse, et je vous donnerai uniquement sa fiche.');return}
 if(/\b(couleur|coloris)\b/.test(t)&&current){const colors={3:'Noir habituellement ; disponibilité à confirmer, sans choix de couleur obligatoire.',5:'Noir, marron, bleu, gris, selon disponibilité.',12:'Noir, bleu, gris, silver, selon disponibilité. Pas de marron.'};say('🎨 '+(colors[current.id]||'Les couleurs disponibles doivent être confirmées pour votre modèle exact.'));return}
 if(/\b(heure|horaire|ouvert|atelier|pose)\b/.test(t)&&current?.id===2){say('🕘 Pose Hydrogel UV à l’atelier : lundi au samedi, de 9 h à 17 h. Pas de livraison pour la pose.');return}
 if(/\b(application|sans application|ic certifi|avec appli|sans appli)\b/.test(t)&&current?.id===3){smartCaseAnswer(raw,true);return}
 if(/\b(paiement|payer|mobile money|m.?pesa|airtel money|orange money)\b/.test(t)){say('💳 Paiements acceptés à l’établissement : espèces, Airtel Money, M-Pesa et Orange Money. Les conditions de paiement à distance sont à confirmer avec notre équipe.');return}
 if(current?.id===3&&smartParse(raw))return smartCaseAnswer(raw,true);
 const found= /^(?:iphone\s*)?(?:11|12|13|14|15|16|17|18)\s*(?:simple|normal|standard|pro|pro max|promax|plus)?$/i.test(t) ? P[0] : findProduct(raw);
 if(found){if(ctx&&found.id===1&&ctx.id!==1&&!/\b(telephone|acheter un telephone|smartphone)\b/.test(t)&&/\b(?:s\s*\d{2}|fold|flip|note\s*\d+|iphone\s*\d+)\b/.test(t)){current=ctx;priceInfo(ctx,raw)||intro(ctx,raw);return}
  if(current?.id!==found.id){lastPrice='';lastModel=''}current=found;if(caseProductAnswer(found,raw))return;if(found.id===1){if(/\b(?:telephone|smartphone|samsung|iphone|pixel|tecno|infinix|itel|jbl|tab)\b/.test(t)&&!(/\d/.test(t))){say('📱 Quel modèle exact recherchez-vous ? Écrivez-le simplement.');return}phoneSearch(raw);return}
  if(!priceInfo(found,raw))intro(found);return}
 if(current){if(priceInfo(current,raw))return;
  if(/\b(comment|caracteristique|protection|stylet|anti casse|compatib|detail|fonctionne|qualite)\b/.test(t)){say('ℹ️ '+current.name+'\n\n'+current.details.map(x=>'• '+x).join('\n')+'\n\nPour une autre question technique, notre équipe peut vérifier le modèle exact.');showSource(current);return}
  if(/\b(salut|bonjour|bonsoir|merci|ok|d'accord|oui|non)\b/.test(t)&&t.length<30){say('Je vous écoute. Quelle question avez-vous sur '+current.name+' ?');return}}
 if(/\b(salut|bonjour|bonsoir|hello|bjr)\b/.test(t)&&t.length<25){say('👋🏾 Vous souhaitez acheter quel article, s’il vous plaît ?');return}
 if(/\b(autre produit|autres produits|vous vendez quoi|je cherche autre chose)\b/.test(t)){say('✍️ Écrivez librement le nom de l’article que vous cherchez. S’il ne figure pas dans nos fiches, nous transmettrons votre demande sur WhatsApp pour vérifier le prix et le stock.');return}
 if(waiting?.kind==='unknown'){const original=waiting.original;waiting=null;handoff('Article recherché : '+original+' / précision : '+raw);return}
 waiting={kind:'unknown',original:raw};say('Pardon 😊 Je veux bien vous répondre, mais je n’ai pas bien compris. Pouvez-vous préciser le nom de l’article ou votre question ? Si nous n’avons pas cette information, notre équipe pourra vous aider.');buttons([['📲 Demander à notre équipe',()=>{waiting=null;handoff(raw)}]]);
}

// V9 : dialogue local contextuel. Les questions simples restent sur le site.
// Les informations non confirmées ne sont jamais inventées.
let dialogueTopic='', dialogueModel='', clarificationCount=0, pendingPhoto=false;
const oldProcess=process;
function msgIs(t,regex){return regex.test(t)}
function familyDevice(t){
 const x=understand(lingalaNormalize(t));
 let m=x.match(/\b(?:fold|zf)\s*([2-8])\s*(ultra)?\b/);if(m)return 'Samsung Z Fold '+m[1]+(m[2]?' Ultra':'');
 m=x.match(/\b(?:flip|zfl)\s*([2-7])\b/);if(m)return 'Samsung Z Flip '+m[1];
 m=x.match(/\b(?:iphone|ip)\s*(xr|1[1-8])\s*(pro\s*max|pro|max|plus|simple)?\b/);if(m)return 'iPhone '+m[1]+(m[2]?' '+m[2]:'');
 m=x.match(/\b(?:samsung\s*)?s\s*(9|10|20|21|22|23|24|25|26)\s*(ultra|u|plus|\+|fe|e)?\b/);if(m)return 'Samsung S'+m[1]+(m[2]?' '+m[2]:'');
 m=x.match(/\b(?:samsung\s*)?a\s*(0?6|16|17|36|55|56)\b/);if(m)return 'Samsung A'+m[1];
 return '';
}
function questionAnswer(raw){
 const t=understand(lingalaNormalize(raw));
 const s=norm(raw);
 // En contexte, une question courte concerne toujours le dernier article.
 if(/^(?:prix|combien|c combien|combien ca coute|combien sa coute|talo|mbongo boni|eza combien|prix svp|combien svp|c est a combien|a combien|c combien svp|et le prix|son prix|prix na yango)[ ?!.,]*$/.test(t)||/^(?:prix|combien|c combien|mbongo boni|talo nini)[ ?!.,]*$/.test(s)){
   if(current?.id===1&&dialogueModel){phoneSearch(dialogueModel);return true}
   if(current?.id===3&&dialogueModel){smartCaseAnswer(dialogueModel,true);return true}
   if(current){priceInfo(current,'quel prix svp');return true}
   say('Bien sûr 😊 Pour quel article souhaitez-vous connaître le prix ?');return true;
 }
 if(/\b(?:photo|foto|f0to|image|voir la photo|montre moi|montrer|voir le modele|vous avez les photos|envoyez.*photo)\b/.test(t)){
   if(current){photo(current);return true}
   pendingPhoto=true;say('Bien sûr 😊 De quel article souhaitez-vous voir la photo ? Je montrerai uniquement les photos originales disponibles.');return true;
 }
 if(pendingPhoto){const p=findProduct(t);if(p&&p.id!==1){pendingPhoto=false;current=p;photo(p);return true}}
 if(/\b(?:vous etes ou|vouz etes ou|vous etes ou exactement|vous etes situe|vous ete ou|bozali wapi|boza wapi|esika nini|c est ou|vous etes vers ou|ou se trouve|ou est le magasin|adresse|localisation|local c4|memling|adresse na bino|position)\b/.test(t)){addr();return true}
 if(/\b(?:livraison|livrer|livre|expedition|expedier|transport|frais de livraison|vous livrez|bo memaka|bomemaka|botindaka|chez moi|a domicile)\b/.test(t)&&!(/\b(?:pochette|telephone|fold|flip|iphone|samsung|tecno|pixel|infinix|itel)\b/.test(t)&&/\b(?:cherche|veux|besoin|prix|combien)\b/.test(t))){delivery();return true}
 if(/\b(?:stock|disponible|dispo|disponibilite|vous en avez|il en reste|il reste|encore|eza disponible|boza na stock|ezali disponible)\b/.test(t)&&!(/\b(?:quel|quels|liste|pochette|coque)\b/.test(t)&&/\b(?:fold|flip|iphone|samsung|tecno)\b/.test(t))){
   say('📦 Pour '+(dialogueModel||current?.name||'cet article')+', je peux vous donner les modèles et les prix publiés. Le stock exact se confirme lors de la commande. Souhaitez-vous préparer votre commande ici ?');
   if(current)buttons([['🛒 Préparer ma commande',()=>startOrder(current),true]]);return true;
 }
 if(/\b(?:comment commander|comment on commande|comment acheter|comment passer commande|je fais comment|je commande comment|comment faire la commande|comment passer ma commande|procedure|demarche)\b/.test(t)){
   if(current){say('C’est simple 😊 Nous préparons votre commande ici, avec le modèle exact, la quantité, votre ville, votre adresse et un numéro. Vous vérifiez ensuite le récapitulatif avant de l’envoyer sur WhatsApp.');buttons([['🛒 Préparer ma commande',()=>startOrder(current),true]]);return true}
   say('C’est simple 😊 Dites-moi d’abord quel article vous souhaitez acheter. Je vous expliquerai ses caractéristiques et son prix avant de préparer la commande.');return true;
 }
 if(/\b(?:payer|paiement|payement|especes|cash|airtel money|m pesa|mpesa|orange money|moyen de paiement|mobile money)\b/.test(t)){
   say('💳 À notre établissement, nous acceptons les espèces, Airtel Money, M-Pesa et Orange Money. Pour une commande à distance, les modalités sont confirmées avant validation.');return true;
 }
 if(/\b(?:vous ouvrez|vous fermez|heure|horaire|quand passer|quel jour|samedi|dimanche|ouverture|atelier)\b/.test(t)&&(!/\b(?:acheter|cherche|veux|pochette|telephone)\b/.test(t))){
   say('🕘 Pour la pose d’anti-casse Hydrogel UV : lundi au samedi, de 9 h à 17 h, au Local C4, Galerie Dubaï Mall. Pour les autres achats, indiquez le jour souhaité afin que notre équipe confirme votre passage.');return true;
 }
 if(/\b(?:garantie|original|authentique|vrai|qualite|resistant|solide|protege|durable|anti choc|anti rayure|c est bien|ca protege|comment ca marche|comment fonctionne|fonctionnement)\b/.test(t)&&current){
   say('Bonne question 😊 Voici les informations indiquées pour '+current.name+' :\n\n'+current.details.map(x=>'• '+x).join('\n')+'\n\nSi vous avez un modèle précis, dites-le-moi pour vérifier la compatibilité.');return true;
 }
 if(/\b(?:vous avez quoi|qu est ce que vous vendez|vous vendez quoi|quels articles|vos produits|votre catalogue|autres articles)\b/.test(t)){
   say('Nous proposons notamment des téléphones, des pochettes Samsung et iPhone, des protections d’écran Hydrogel UV, des tablettes et des accessoires. 😊\n\nDites-moi simplement ce que vous cherchez ; je vous présenterai uniquement les informations correspondantes.');return true;
 }
 if(/^(?:oui|ok|okay|d accord|dacc|c est bon|ca marche|bien|super|merci|matondi|merci beaucoup|ah ok|compris|non merci|non)[ !?.]*$/.test(t)){
   say(/merci|matondi/.test(t)?'Avec plaisir 😊 Je reste à votre écoute si vous avez une question.':'D’accord 😊 Je vous écoute.');return true;
 }
 return false;
}
function detailFollowup(raw){
 const t=understand(lingalaNormalize(raw));
 const device=familyDevice(raw);
 // Le téléphone précisé seul après une question de pochette ne devient pas un achat de téléphone.
 if(device&&current&&current.id!==1&&!/\b(?:robot|rabat|magsafe|silicone|design\s*119|smart\s*window|caoutchouc|2\s*en\s*1)\b/.test(t)){
   dialogueModel=device;lastModel=device;
   if(current.id===3)return smartCaseAnswer(raw,true);
   if(current.id===4&&/fold/.test(t))return foldList('pochette '+t);
   if(caseProductAnswer(current,raw))return true;
   if(current.id===2){say('Merci 😊 Pour '+device+', nous proposons les protections Hydrogel UV selon la compatibilité : téléphone vue claire 5 $, privacy 10 $ ; écran interne pliable 15 $. La pose se fait à notre atelier.');buttons([['🗓️ Réserver une pose',()=>openRequestForm('reservation',current),true]]);return true}
   intro(current,device);return true;
 }
 if(/\b(?:intelligente|inteligente|inteligent|smart cover|pochette ic|avec appli|sans appli)\b/.test(t)){
   current=P[2];dialogueTopic='intelligente';if(device){dialogueModel=device;return smartCaseAnswer(raw,true)}return smartCaseAnswer(raw,true);
 }
 if(/\b(?:pochette|coque|housse|etui|cover|pochete|pochet|poch|coq)\b/.test(t)&&/\b(?:fold|zf|zfold|folde)\b/.test(t)&&!(/\b(?:robot|rabat|magsafe|design|intelligente|smart window|2 en 1)\b/.test(t))){
   dialogueTopic='fold';if(device)dialogueModel=device;return foldList(t);
 }
 if(/\b(?:pochette|coque|housse|etui|cover|pochete|pochet|poch|coq)\b/.test(t)&&!device&&!/\b(?:intelligente|robot|magsafe|design|rabat|silicone|flip|fold)\b/.test(t)){
   say('Avec plaisir 😊 Pour quel téléphone souhaitez-vous la pochette ? Écrivez le modèle, par exemple Z Fold 2, S24 Ultra ou iPhone 14.');waiting={kind:'case'};return true;
 }
 if(/\b(?:anti casse|anticasse|hydrogel|privacy|verre trempe|film ecran|protection ecran|vitre de protection)\b/.test(t)&&!(/\b(?:pochette|coque)\b/.test(t))){
   current=P[1];if(device)dialogueModel=device;intro(P[1],device);return true;
 }
 if(device&&!current&&!/\b(?:robot|rabat|magsafe|silicone|design\s*119|smart\s*window|caoutchouc|2\s*en\s*1)\b/.test(t)){
   dialogueModel=device;
   if(/\b(?:pochette|coque|housse|etui)\b/.test(t)){
     if(/fold/.test(t))return foldList('pochette '+t);
     say('D’accord 😊 Vous cherchez une pochette pour '+device+'. Quel type de pochette vous intéresse ?');waiting={kind:'case'};return true;
   }
   // Sans article explicite, demander sans supposer le téléphone à vendre.
   if(!/\b(?:telephone|tel|acheter|achat|prix|combien|cout|smartphone)\b/.test(t)){
     say('Merci 😊 Vous parlez de '+device+'. Vous cherchez le téléphone lui-même, une pochette ou un anti-casse ?');waiting={kind:'device-choice',device};return true;
   }
 }
 if(waiting?.kind==='device-choice'){
   const d=waiting.device;
   if(/\b(?:telephone|tel|appareil|1)\b/.test(t)){waiting=null;return phoneSearch(d)}
   if(/\b(?:pochette|coque|etui|housse|2)\b/.test(t)){waiting=null;dialogueModel=d;if(/fold/.test(d.toLowerCase()))return foldList('pochette '+d);say('D’accord 😊 Quelle pochette recherchez-vous pour '+d+' ?');return true}
   if(/\b(?:anticasse|anti casse|protection|3)\b/.test(t)){waiting=null;current=P[1];dialogueModel=d;intro(P[1],d);return true}
 }
 return false;
}
function helpfulFallback(raw){
 const t=understand(lingalaNormalize(raw));
 if(/\b(?:samsung|iphone|pixel|tecno|infinix|itel|jbl|boombox|camon|spark|hot|note|smart|pop|tab|galaxy)\b/.test(t)&&!current){return phoneSearch(raw)}
 if(current){
   if(clarificationCount<2){clarificationCount++;
     say('Je veux bien vous répondre 😊 Vous parlez toujours de '+current.name+' ? Vous pouvez préciser votre question en quelques mots (prix, modèle, photo, livraison ou commande).');return true;
   }
   say('Je n’ai pas assez d’informations pour vous répondre avec certitude. Vous pouvez expliquer votre demande ici, ou demander une vérification à notre équipe.');
   buttons([['📝 Expliquer ma demande',()=>openRequestForm('demande',current)],['📲 Contacter notre équipe',()=>handoff(raw)]]);return true;
 }
 if(clarificationCount<2){clarificationCount++;
   say('Pardon 😊 Vous cherchez quel article exactement ? Vous pouvez écrire son nom même en abrégé, par exemple « pochette Fold 4 », « S24 Ultra », « anti-casse 14 » ou « chargeur ».');return true;
 }
 say('Merci 😊 Je ne reconnais pas encore cet article. Écrivez son nom dans le formulaire et notre équipe pourra confirmer son prix et sa disponibilité.');buttons([['📩 Décrire mon article',()=>openRequestForm('demande',null),true]]);return true;
}
process=function(raw){
 const t=understand(lingalaNormalize(raw));
 last=raw;
 if(/\b(?:reclamation|reclamer|plainte|probleme de commande|pas conforme|abime|casse|remboursement|retour|mauvais article|erreur de commande)\b/.test(t)){clarificationCount=0;return oldProcess(raw)}
 if(state)return oldProcess(raw);
 // Conserver la commande et le contexte, ne pas détourner les questions ordinaires.
 if(waiting?.kind==='offer'||waiting?.kind==='iphone')return oldProcess(raw);
 if(/^(?:oh|non|oh non|je veux|je cherche|un|le|pour|prix|telephone|iphone)?\s*(?:xr|1[1-8])\s*(?:simple|normal|standard)?\s*(?:svp|stp)?$/.test(t)){clarificationCount=0;return oldProcess(raw)}
 if(/\b(?:trop cher|c est cher|eza cher|ezali cher|talo mingi|kitisa|negocier|negociation|remise|reduction|rabais|dernier prix|faire prix|je vais reflechir|je vais voir|j hesite|c est solide|c est de bonne qualite|quel avantage|pourquoi acheter|conseillez moi)\b/.test(t)){if(conversationalHelp(raw)){clarificationCount=0;return}}
 if(/^(?:bonjour|bonsoir|salut|bjr|bsr|mbote|hello)(?:\s+svp)?[ !?.]*$/.test(t)){say('Salut 👋🏾 Vous souhaitez acheter quel article, s’il vous plaît ?');clarificationCount=0;return}
 if(questionAnswer(raw)){clarificationCount=0;return}
 if(detailFollowup(raw)){clarificationCount=0;return}
 // Les recherches de produits explicites et commandes passent au moteur V8.
 const likely=/\b(?:pochette|coque|housse|etui|fold|flip|iphone|samsung|galaxy|robot|rabat|design|magsafe|silicone|intelligente|telephone|tecno|infinix|itel|pixel|jbl|tablette|chargeur|casque|ecouteurs|commande|commander|acheter|troc|reservation|photo|prix|stock|livraison|adresse|anticasse|hydrogel|protection|disponible)\b/.test(t);
 if(likely){const prev=waiting;waiting=null;const oldSay=say;let didFallback=false;
   say=function(txt,...args){if(/^Pardon 😊 Je veux bien vous répondre|^Pour vous répondre avec précision, notre équipe doit vérifier/.test(txt)){didFallback=true;return}return oldSay(txt,...args)};
   try{oldProcess(raw)}finally{say=oldSay}
   if(didFallback){waiting=prev;return helpfulFallback(raw)}
   clarificationCount=0;return;
 }
 if(/^(?:je cherche|je veux|vous avez|nalingi|nazali koluka|j ai besoin de)\s+.{3,}$/.test(t)){
   say('Merci 😊 Je n’ai pas trouvé de fiche confirmée pour « '+raw.trim()+' ». Vous pouvez préciser la marque ou la référence ; sinon nous préparerons une demande de prix et de disponibilité.');
   buttons([['📝 Préciser mon article',()=>openRequestForm('demande',null)]]);return;
 }
 return helpfulFallback(raw);
};

// Assistant IA réel : les messages sont envoyés à la fonction Netlify, jamais directement à OpenAI.
const aiHistory=[];
let aiBusy=false;
async function aiReply(raw){
  // Les formulaires de commandes et réclamations restent traités localement.
  if(state){process(raw);return}
  const normalized=norm(raw);
  if(/\b(reclamation|plainte|remboursement|probleme avec ma commande|article abime|mauvais produit|pas conforme)\b/.test(normalized)){
    openRequestForm('reclamation',current);return;
  }
  const pending=say('Un instant, je vérifie pour vous…');
  aiBusy=true;
  try{
    const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),22000);
    let response;
    try{response=await fetch('/.netlify/functions/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:raw,context:{slug:current?.slug||null,model:lastModel||''},history:aiHistory.slice(-8)}),signal:ctrl.signal})}finally{clearTimeout(timer)}
    if(!response.ok)throw new Error('IA indisponible');
    const data=await response.json();if(!data.reply)throw new Error('Réponse vide');
    pending.textContent=data.reply;
    const p=P.find(x=>x.slug===data.slug)||current||null;
    if(p)current=p;
    if(data.model)lastModel=data.model;
    aiHistory.push({role:'user',content:raw},{role:'assistant',content:data.reply});
    if(aiHistory.length>16)aiHistory.splice(0,aiHistory.length-16);
    switch(data.action){
      case 'photo':photo(p);break;
      case 'order':if(p)openRequestForm('commande',p);else buttons([['🛒 Préciser l’article',()=>openRequestForm('demande',null),true]]);break;
      case 'reservation':openRequestForm('reservation',p);break;
      case 'complaint':openRequestForm('reclamation',p);break;
      case 'trade':openRequestForm('troc',p);break;
      case 'source':if(p)showSource(p);break;
      case 'unknown':buttons([['📩 Préparer ma demande',()=>openRequestForm('demande',p)]]);break;
      default: if(p && /\b(acheter|commander|je prends|je le prends)\b/.test(normalized))buttons([['🛒 Commander',()=>openRequestForm('commande',p),true]]);
    }
  }catch(err){
    pending.remove();
    // Dégradation gracieuse : moteur V9 local, aucun prix inventé.
    process(raw);
  }finally{aiBusy=false;scroll()}
}
document.getElementById('composer').addEventListener('submit',e=>{
  e.preventDefault();if(aiBusy)return;const t=input.value.trim();if(!t)return;
  say(t,true);input.value='';last=t;aiReply(t);
});
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();document.getElementById('composer').requestSubmit()}});
document.getElementById('help').addEventListener('click',()=>{say('ℹ️ Écrivez votre article ou votre question. Aucun prix n’est inventé. Si je ne connais pas la réponse, je vous aiderai à contacter notre équipe sur WhatsApp.');if(current)showSource(current)});



// V7 — Demandes finales en un seul formulaire court, sans demander de couleur.
// Aucune donnée client n'est envoyée à un serveur ; seul le client ouvre WhatsApp
// et appuie lui-même sur Envoyer. Les photos du client ne sont pas téléversées.
let pendingProduct=null;
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e}
function openRequestForm(kind,p){
  pendingProduct=p||current||null;state=null;waiting=null;
  const title={commande:'🛒 Préparons votre commande',reservation:'🗓️ Réservons votre passage à l’atelier',troc:'🔄 Préparons votre rendez-vous',reclamation:'📝 Enregistrons votre réclamation',demande:'📩 Préparons votre demande'}[kind];
  say(title+' 😊\nRemplissez seulement ces quelques informations. Rien ne sera envoyé sans votre accord.');
  const card=el('div','quickForm'),f=el('form','requestForm');
  const fields=[];
  function field(key,label,placeholder,required=false,initial='',type='text'){
    const wrap=el('label','requestField'),cap=el('span','',label);let x=type==='textarea'?document.createElement('textarea'):document.createElement('input');
    if(type!=='textarea')x.type=type==='tel'?'tel':'text';x.name=key;x.placeholder=placeholder||'';x.value=initial||'';x.required=required;x.autocomplete='off';wrap.append(cap,x);f.append(wrap);fields.push(x);return x;
  }
  if(kind==='commande'){
    field('article','Article','Nom du produit',true,p?.name||'');
    field('modele','Modèle du téléphone (si nécessaire)','Ex. : Z Fold 4 ou iPhone 14 Pro',!!(p&&/pochette|anticasse|anti.casse|hydrogel|telephone/i.test(p.name)),lastModel||'');
    field('version','Version / stockage (si nécessaire)','Ex. : rabat 35 $ ou 256 Go',false,'');
    field('quantite','Quantité','1',true,'1');
    field('ville','Ville','Ex. : Kinshasa',true,'');
    field('adresse','Commune et adresse / lieu de retrait','Ex. : Gombe, avenue...',true,'');
  }else if(kind==='reservation'){
    field('article','Appareil à protéger','Ex. : Samsung S24 Ultra',true,lastModel||'');
    field('version','Protection souhaitée','Vue claire / Privacy / écran interne',true,'');
    field('date','Jour et heure souhaités','Ex. : samedi à 11 h',true,'');
  }else if(kind==='troc'){
    field('article','Téléphone à échanger','Marque, modèle, stockage',true,'');
    field('version','Téléphone recherché','Modèle souhaité',true,'');
    field('date','Jour et heure souhaités','Ex. : vendredi à 14 h',true,'');
  }else if(kind==='reclamation'){
    field('article','Article / commande concernée','Ex. : Pochette Z Fold 5',true,current?.name||'');
    field('details','Expliquez votre réclamation','Dites-nous ce qui s’est passé, avec vos propres mots',true,'','textarea');
    field('reference','Référence de commande (si vous en avez une)','Facultatif');
  }else{
    field('article','Article recherché','Nom ou description du produit',true,last||'');
    field('details','Votre question','Précisez ce que vous souhaitez savoir',true,'','textarea');
  }
  field('telephone','Votre numéro WhatsApp','Ex. : 08… ou +243…',true,'','tel');
  field('nom','Nom (facultatif)','Facultatif');
  if(kind==='commande')field('note','Précision supplémentaire (facultative)','Facultatif');
  const foot=el('div','requestButtons');const cancel=el('button','action','Annuler');cancel.type='button';cancel.addEventListener('click',()=>{card.remove();say('D’accord 😊 Vous pouvez continuer à poser vos questions.');});
  const submit=el('button','action primary','Vérifier mon récapitulatif');submit.type='submit';foot.append(cancel,submit);f.append(foot);card.append(f);chat.append(card);scroll();
  f.addEventListener('submit',ev=>{
    ev.preventDefault();const data=Object.fromEntries(new FormData(f).entries());
    if(data.telephone.replace(/\D/g,'').length<9){say('📞 Merci de vérifier votre numéro WhatsApp.');return}
    if(kind==='commande'&&/\bfold\s*2\b/i.test(data.modele)&&/\b45\s*\$?/.test(data.version)){say('⚠️ Le modèle 2-en-1 MagSafe à 45 $ n’est pas indiqué pour Z Fold 2. Choisissez une autre version avant de confirmer.');return}
    const type={commande:'🛒 COMMANDE CLIENT',reservation:'🗓️ RÉSERVATION ANTI-CASSE',troc:'🔄 RENDEZ-VOUS TROC / CONTRE-VALEUR',reclamation:'📝 RÉCLAMATION CLIENT',demande:'📩 DEMANDE DE RENSEIGNEMENT'}[kind];
    const labels={article:'📦 Article',modele:'📱 Téléphone / modèle',version:'📋 Version / stockage',quantite:'🔢 Quantité',ville:'📍 Ville',adresse:'🏠 Adresse',date:'🕘 Passage souhaité',details:'💬 Explications',reference:'🧾 Référence',telephone:'📞 Contact',nom:'👤 Nom',note:'📝 Précision'};
    const lines=[type,'FULL BUSINESS INTERNATIONAL',''];
    for(const [key,label] of Object.entries(labels)){if(String(data[key]||'').trim())lines.push(label+' : '+String(data[key]).trim())}
    if(kind==='commande')lines.push('💵 Prix final : à confirmer selon la variante publiée','🚚 Frais de livraison : à confirmer','📦 Disponibilité : à confirmer','📸 Pour une pochette, joindre la capture « À propos du téléphone » dans WhatsApp.');
    if(kind==='reservation')lines.push('📍 Atelier : Galerie Dubaï Mall, Local C4, Kinshasa-Gombe','🕘 Lundi–samedi, 9 h–17 h','📌 Horaire : sous réserve de confirmation.');
    if(kind==='troc')lines.push('📍 Évaluation uniquement sur place, Local C4','💵 Valeur de reprise : uniquement après examen physique.');
    if(kind==='reclamation')lines.push('📸 Si vous avez une photo ou une preuve, joignez-la directement dans WhatsApp.');
    lines.push('','Merci de confirmer.');
    card.remove();say('Merci 😊 Voici votre récapitulatif :\n\n'+lines.join('\n')+'\n\nVérifiez les informations. Votre demande n’est pas encore envoyée.');
    buttons([['📲 Envoyer la demande finale',()=>openDirect(wa(lines.join('\n'))),true],['✏️ Corriger',()=>openRequestForm(kind,p)]]);
  });
}
function handlePriority(raw){
 const t=understand(lingalaNormalize(raw));
 if(/\b(reclamation|reclamer|plainte|probleme de commande|probleme avec ma commande|article abime|article casse|produit casse|pas conforme|mauvais produit|je suis decu|livraison en retard|erreur de commande|remboursement|retour produit|echanger mon article|garantie|sav)\b/.test(t)){
  say('Je suis désolé pour ce désagrément. 🙏🏾 Expliquez-nous ce qui s’est passé ; nous examinerons votre réclamation avec attention.');openRequestForm('reclamation',current);return true;
 }
 if(/\b(envoyer (une |la )?photo|je peux envoyer (une |la )?photo|joindre (une |la )?photo|ajouter (une |la )?photo|photo de mon probleme|photo de la reclamation|capture d ecran|preuve en photo)\b/.test(t)){
  say('📸 Vous pouvez joindre votre photo ou votre capture directement dans WhatsApp, après avoir préparé votre réclamation ou votre commande ici. Le site ne transfère pas les images automatiquement.');buttons([['📝 Faire une réclamation',()=>openRequestForm('reclamation',current)],['🛒 Préparer une commande',()=>current?startOrder(current):say('Quel article souhaitez-vous commander ?')]]);return true;
 }
 if(/\b(je veux (faire|deposer) une reclamation|je souhaite signaler|signaler un probleme)\b/.test(t)){openRequestForm('reclamation',current);return true}
 if(/\b(comment commander|je veux commander|je commande|passer commande|je prends|je le prends|je vais acheter|je veux acheter|commander maintenant|reserver|reservation)\b/.test(t)&&current){
   if(current.id===2||/\b(reserv|pose|rendez vous)\b/.test(t)&&current.id===2){openRequestForm('reservation',current)}else startOrder(current);return true;
 }
 if(/\b(je cherche autre chose|produit introuvable|article introuvable|vous n avez pas|vous n'avez pas)\b/.test(t)){
  say('Avec plaisir 😊 Dites-nous le nom de l’article que vous recherchez. Si son prix n’est pas dans notre liste, nous préparerons une demande pour notre équipe.');buttons([['📩 Demander un article particulier',()=>openRequestForm('demande',current)]]);return true;
 }
 // Contexte d'une publicité : une référence seule décrit l'appareil, pas un changement de rayon.
 if(current&&current.id!==1&&/^(?:(?:samsung|galaxy)\s*)?(?:(?:z\s*)?(?:fold|flip)\s*[2-8]|s\s*(?:9|10|20|21|22|23|24|25|26)(?:\s*(?:ultra|plus|\+|fe))?|note\s*(?:10|20)(?:\s*(?:ultra|plus|\+))?|(?:iphone\s*)?(?:xr|1[1-8])(?:\s*(?:pro|max|plus|simple|pro max))?)$/.test(t)){
  lastModel=raw.trim();if(current.id===3){if(!priceInfo(current,raw))intro(current,raw)}else if(current.id===4&&/fold/.test(t)){foldList('pochette '+t)}else if(!caseProductAnswer(current,raw)){say('Merci 😊 Vous avez indiqué : '+lastModel+'.\n\n'+current.details.map(x=>'• '+x).join('\n')+'\n\nLa compatibilité et la disponibilité seront vérifiées avant la commande.');showSource(current)}return true;
 }
 return false;
}
