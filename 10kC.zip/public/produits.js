window.FBI_PRODUITS=[
  {
    "id": 1,
    "slug": "telephones",
    "name": "Téléphones, tablettes et accessoires",
    "url": "https://beamish-faun-b3abb4.netlify.app/",
    "local": "fiches/01/index.html",
    "photo": null,
    "photos": [],
    "details": [
      "Téléphones Samsung, iPhone, Google Pixel, Tecno, Infinix et Itel.",
      "Tablettes, JBL, audio et accessoires selon la liste fournie.",
      "Prix selon le modèle et le stockage. Disponibilité à confirmer."
    ]
  },
  {
    "id": 2,
    "slug": "anticasse",
    "name": "Protection d’écran Hydrogel UV",
    "url": "https://sweet-maamoul-5647ce.netlify.app/",
    "local": "fiches/02/index.html",
    "photo": "assets/source02_1.jpg",
    "photos": [
      "assets/source02_1.jpg"
    ],
    "details": [
      "Film Hydrogel UV posé uniquement à notre atelier.",
      "Téléphone vue claire : 5 $ ; privacy/fumée : 10 $.",
      "Tablette vue claire : 10 $ ; privacy : 15 $.",
      "Écran interne Z Fold/Z Flip : 15 $. Lentilles caméra : à partir de 5 $.",
      "Lundi au samedi de 9 h à 17 h."
    ]
  },
  {
    "id": 3,
    "slug": "intelligente",
    "name": "Pochettes intelligentes Samsung",
    "url": "https://ornate-empanada-3d2a5e.netlify.app/",
    "local": "fiches/03/index.html",
    "photo": "assets/pochettes-intelligentes-original.jpg",
    "photos": [
      "assets/source03_1.png"
    ],
    "details": [
      "Pochette intelligente Samsung : fermeture magnétique, affichage de l’heure, appels, SMS et batterie selon le modèle ; finition premium.",
      "IC SANS APPLICATION : S24/S24+/S24 Ultra 65 $ ; S23/S23+/S23 Ultra 60 $ ; S22/S22+/S22 Ultra 55 $ ; S21/S21+/S21 Ultra 50 $ ; S20/S20+/S20 Ultra 35 $ ; S10/S10+ 30 $.",
      "IC SANS APPLICATION : Note 10/Note 10+ 35 $ ; Note 20/Note 20 Ultra 40 $.",
      "AVEC APPLICATION : S25/S25+/S25 FE/S25E 50 $ ; S26/S26+ 50 $ ; S25 Ultra/S26 Ultra 65 $ ; S23 FE/S24 FE 40 $.",
      "AVEC APPLICATION : Z Fold 3/4/5/6/7/8/8 Ultra 45 $ ; A16/A17/A36 25 $ ; A55/A56 30 $.",
      "Pour les versions avec application, une activation est nécessaire ; ne pas confondre avec les modèles IC sans application.",
      "Couleur habituelle : noir, sous réserve de disponibilité. Aucune couleur demandée obligatoirement.",
      "Le prix et le stock de la référence exacte sont confirmés avant commande."
    ]
  },
  {
    "id": 4,
    "slug": "zfold",
    "name": "Pochettes Z Fold — 30 $, 35 $, 45 $",
    "url": "https://inquisitive-basbousa-6ff933.netlify.app/",
    "local": "fiches/04/index.html",
    "photo": "assets/source04_2.jpg",
    "photos": [
      "assets/source04_2.jpg",
      "assets/source04_3.jpg",
      "assets/source04_4.jpg"
    ],
    "details": [
      "Pochette rabat sans stylet : 30 $.",
      "Pochette rabat avec stylet et anti-casse : 35 $.",
      "Pochette 2-en-1 MagSafe : 45 $ pour Z Fold 3 à 7, sans stylet.",
      "Z Fold 2 : le rabat à 30 $ ne comporte pas d’anti-casse intégré.",
      "Z Fold 8/8 Ultra : compatibilité à confirmer selon la version."
    ]
  },
  {
    "id": 5,
    "slug": "robotcf1",
    "name": "Pochette Robot CF1",
    "url": "https://cosmic-speculoos-ef7662.netlify.app/",
    "local": "fiches/05/index.html",
    "photo": "assets/source05_2.jpg",
    "photos": [
      "assets/source05_2.jpg"
    ],
    "details": [
      "Samsung Z Fold 3 à 7 : 35 $.",
      "Cuir et caoutchouc, anti-casse intégré et stylet magnétique détachable.",
      "Couleurs proposées : noir, marron, bleu, gris — stock à confirmer."
    ]
  },
  {
    "id": 6,
    "slug": "zflip",
    "name": "Pochette Z Flip en caoutchouc",
    "url": "https://keen-daifuku-8d12de.netlify.app/",
    "local": "fiches/06/index.html",
    "photo": "assets/source06_2.jpg",
    "photos": [
      "assets/source06_2.jpg"
    ],
    "details": [
      "Samsung Z Flip 3 à 7 : 15 $.",
      "Pochette en caoutchouc, protection contre rayures et petits chocs.",
      "Une version cuir à 20 $ figure dans les informations communiquées, disponibilité à confirmer."
    ]
  },
  {
    "id": 7,
    "slug": "multifonction",
    "name": "Pochette Rabat multifonction",
    "url": "https://shiny-wisp-9018ba.netlify.app/",
    "local": "fiches/07/index.html",
    "photo": "assets/source07_2.jpg",
    "photos": [
      "assets/source07_2.jpg"
    ],
    "details": [
      "Samsung et iPhone : 20 $.",
      "Rabat multifonction, rangement de cartes, selon modèle.",
      "Couleur et compatibilité à confirmer."
    ]
  },
  {
    "id": 8,
    "slug": "2en1",
    "name": "Pochette 2-en-1 MagSafe",
    "url": "https://statuesque-babka-99429e.netlify.app/",
    "local": "fiches/08/index.html",
    "photo": "assets/source08_2.jpg",
    "photos": [
      "assets/source08_2.jpg"
    ],
    "details": [
      "Samsung Z Fold 3 à 7 : 45 $.",
      "Samsung S24/S25/S26 Ultra : 35 $.",
      "iPhone 14 à 17 Pro Max : 35 $.",
      "Coque détachable MagSafe, rabat multifonction et protection contre les chocs.",
      "Z Fold : anti-casse intégré, sans stylet."
    ]
  },
  {
    "id": 9,
    "slug": "design119",
    "name": "Pochette Design 119",
    "url": "https://reliable-sfogliatella-d85b97.netlify.app/",
    "local": "fiches/09/index.html",
    "photo": "assets/source09_2.jpg",
    "photos": [
      "assets/source09_2.jpg"
    ],
    "details": [
      "Samsung Z Fold 2 à 7 : 35 $.",
      "Samsung Z Flip 2 à 7 : 20 $.",
      "Design rabat, finition et options selon la version."
    ]
  },
  {
    "id": 10,
    "slug": "silicone",
    "name": "Pochette Silicone MagSafe iPhone",
    "url": "https://lambent-mousse-676699.netlify.app/",
    "local": "fiches/10/index.html",
    "photo": "assets/source10_2.jpg",
    "photos": [
      "assets/source10_2.jpg"
    ],
    "details": [
      "Pochette silicone MagSafe iPhone : 15 $.",
      "Silicone souple, compatible MagSafe selon modèle.",
      "Couleur et stock à confirmer."
    ]
  },
  {
    "id": 11,
    "slug": "smartwindow",
    "name": "Pochette Smart Window Z Fold",
    "url": "https://gorgeous-daifuku-82682c.netlify.app/",
    "local": "fiches/11/index.html",
    "photo": "assets/source11_2.jpg",
    "photos": [
      "assets/source11_2.jpg"
    ],
    "details": [
      "Pochette Smart Window Samsung Z Fold 3, 4, 5, 6, 7, 8 et 8 Ultra (compatibilité à confirmer).",
      "Fenêtre intelligente et rabat, sans anti-casse intégré.",
      "Tarif publié dans la fiche pour Kinshasa : 45 $ ; ailleurs, tarif à confirmer.",
      "Pour Z Fold 3/4, une proposition à 35 $ peut être examinée, sans acceptation automatique."
    ]
  },
  {
    "id": 12,
    "slug": "robotmagsafe",
    "name": "Pochette Robot MagSafe",
    "url": "https://exquisite-muffin-410fc3.netlify.app/",
    "local": "fiches/12/index.html",
    "photo": "assets/source12_2.jpg",
    "photos": [
      "assets/source12_2.jpg"
    ],
    "details": [
      "Pochette Robot MagSafe Samsung Z Fold 3 à 7 : 35 $ (Z Fold 8 / 8 Ultra à confirmer).",
      "Caoutchouc, MagSafe, anti-casse et stylet selon le modèle.",
      "Couleurs : noir, bleu, gris et silver. Pas de marron.",
      "Compatibilité Z Fold 8/8 Ultra à vérifier."
    ]
  }
];
