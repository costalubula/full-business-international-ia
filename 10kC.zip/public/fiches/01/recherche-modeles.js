/* Recherche de TOUS les produits à partir du catalogue fourni : aucun tarif créé ici. */
(function(){'use strict';
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,' ').replace(/\s+/g,' ').trim();
const key=s=>norm(s).replace(/[^a-z0-9+]/g,'');
const phone=p=>/^(SAMSUNG GALAXY|IPHONE|GOOGLE PIXEL|TECNO|INFINIX|ITEL)/.test(p.category);
const by=(C,category,root,suffix)=>C.filter(p=>p.category===category&&key(p.category==='GOOGLE PIXEL'?p.name.replace(/^google\s+/i,''):p.name).startsWith(root)&&(!suffix||suffix(p)));
const hasBrand=(t,b)=>new RegExp('\\b'+b+'\\b').test(t);
function search(input,C){
 const t=norm(input).replace(/\b(128|256|512|64)\s*(gb|go|giga|gigas)\b/g,' ');
 const c=key(t);let m,found=[];let missing='';
 const samsung=hasBrand(t,'samsung')||hasBrand(t,'galaxy');
 const iphone=hasBrand(t,'iphone')||hasBrand(t,'apple');
 const pixel=hasBrand(t,'pixel')||hasBrand(t,'google');
 const tecno=hasBrand(t,'tecno'),infinix=hasBrand(t,'infinix'),itel=hasBrand(t,'itel');
 const jbl=hasBrand(t,'jbl');
 // Accessoires : leurs noms peuvent contenir « iPhone 16 » ou « Z Fold », sans être des téléphones.
 if(/\b(pochette|pochettes|protection\s+camera|anti\s*casse)\b/.test(t)){
   const subset=C.filter(p=>p.category==='ACCESSOIRES'||p.category==='ANTI-CASSE (POSE EN BOUTIQUE)');
   const tt=key(t);
   const matches=subset.filter(p=>tt.includes(key(p.name))||key(p.name).includes(tt));
   if(matches.length)return {products:matches,missing};
   const subject=/batterie/.test(t)?'batterie':/camera/.test(t)?'camera':/magnetique/.test(t)?'magnetique':/anti\s*casse/.test(t)?'anticasse':'';
   return {products:subject?subset.filter(p=>key(p.name).includes(subject)):subset,missing};
 }
 // Tablettes : « Tab 11 » ne doit jamais être interprété comme iPhone 11.
 if(/\btab\s*(?:a\s*)?11\b/.test(t)){
   const tab=key(t).includes('a11')?'taba11':'tab11';
   return {products:C.filter(p=>p.category==='TABLETTES SAMSUNG'&&key(p.name).startsWith(tab)),missing};
 }
 // Série S : S21 -> S21, S21+, S21 Ultra ; S24 Ultra -> Ultra uniquement.
 m=t.match(/\bs\s*(9|10|20|21|22|23|24|25|26)\s*(ultra|plus|\+)?(?=$|[^a-z0-9])/);
 if(m){const root='s'+m[1],suffix=m[2];found=by(C,'SAMSUNG GALAXY S',root,p=>!suffix||(suffix==='ultra'?/ultra/i.test(p.name):/\+/.test(p.name)));return {products:found,missing};}
 // Samsung Fold / Flip, même si le client écrit « fold 5 ».
 m=t.match(/\b(?:z\s*)?fold\s*(2|3|4|5|6|7|8)\s*(ultra)?\b/);
 if(m){found=by(C,'SAMSUNG GALAXY Z FOLD','zfold'+m[1],p=>!m[2]||/ultra/i.test(p.name));return {products:found,missing};}
 m=t.match(/\b(?:z\s*)?flip\s*(3|4|5|6|7)\b/);
 if(m&&(samsung||/\bz\s*flip\b/.test(t)||!jbl)){found=by(C,'SAMSUNG GALAXY Z FLIP','zflip'+m[1]);return {products:found,missing};}
 // iPhone : « 14 simple » signifie iPhone 14 (absent de la publicité).
 // « 14 Pro » affiche Pro et Pro Max pour comparer ; « 14 Pro Max » cible Max.
 m=t.match(/\b(?:iphone\s*|iph\s*|apple\s*)?(xr|11|12|13|14|15|16|17|18)\s*(pro\s*max|promax|pro|plus|simple|normal|standard)?\b/);
 if(m&&!samsung&&!pixel&&!tecno&&!infinix&&!itel&&!jbl){
   const num=m[1],suffix=key(m[2]||'');
   found=by(C,'IPHONE','iphone'+num,p=>!suffix||(
     suffix==='promax'?key(p.name).endsWith('promax'):
     suffix==='pro'?key(p.name).includes('pro'):
     suffix==='plus'?key(p.name).endsWith('plus'):
     !/pro|max|plus/i.test(p.name)));
   if(['simple','normal','standard'].includes(suffix)&&!found.length){
     missing=`Le prix de l’iPhone ${num} simple n’est pas indiqué dans notre publicité. Je ne peux pas inventer son tarif. Voici les autres iPhone ${num} avec leurs prix publiés :`;
     found=by(C,'IPHONE','iphone'+num);
   }else if(!suffix&&!found.some(p=>key(p.name)==='iphone'+num)){
     missing=`Le prix de l’iPhone ${num} simple n’est pas indiqué dans notre publicité. Voici les variantes de cette famille dont les prix sont publiés :`;
   }
   return {products:found,missing};
 }
 // Google Pixel : Pixel 9 / Pixel 9 Pro / Pixel 9 Pro XL / Pixel 9 Pro Fold.
 m=t.match(/\b(?:google\s*)?pixel\s*(6|7|8|9|10)\s*(pro\s*xl|pro\s*fold|pro|fold|xl)?\b/);
 if(m){const root='pixel'+m[1],suffix=key(m[2]||'');found=by(C,'GOOGLE PIXEL',root,p=>!suffix||(suffix==='pro'?key(p.name).includes('pro'):key(p.name).includes(suffix)));return {products:found,missing};}
 if(/\bpixel\s*fold\b/.test(t)){return {products:C.filter(p=>p.category==='GOOGLE PIXEL'&&key(p.name)==='pixelfold'),missing};}
 // Samsung Note 20 / Note 20 Ultra ; Infinix Note 60 et Note Edge.
 m=t.match(/\bnote\s*(8|9|10|20|60|edge)\s*(ultra|simple|\+|plus)?(?=$|[^a-z0-9])/);
 if(m){const n=m[1],suffix=m[2];if(infinix||n==='60'||n==='edge')found=by(C,'INFINIX','note'+n);else found=by(C,'SAMSUNG GALAXY NOTE','note'+n,p=>!suffix||(suffix==='ultra'?/ultra/i.test(p.name):suffix==='simple'?/simple/i.test(p.name):/\+/.test(p.name)));return {products:found,missing};}
 // Séries A : A06 est présent chez Samsung et Itel. Sans marque, montrer les deux.
 m=t.match(/\ba\s*(06|16|17|25|33|34|35|54|55|57|100c|200\+?|200)(?=$|[^a-z0-9])/);
 if(m){const root='a'+m[1].replace(/\s/g,'');found=C.filter(p=>['SAMSUNG GALAXY A','ITEL'].includes(p.category)&&key(p.name)===root&&(!samsung||p.category==='SAMSUNG GALAXY A')&&(!itel||p.category==='ITEL'));return {products:found,missing:found.length>1?'Ce modèle existe dans plusieurs marques. Choisissez la marque et le stockage souhaités :':''};}
 // Recherche pour toutes les autres références : Tecno, Infinix, Itel, JBL, tablettes, accessoires.
 const categories=tecno?['TECNO']:infinix?['INFINIX']:itel?['ITEL']:jbl?['JBL & AUDIO']:samsung?C.filter(p=>p.category.startsWith('SAMSUNG')||p.category==='TABLETTES SAMSUNG').map(p=>p.category):iphone?['IPHONE']:pixel?['GOOGLE PIXEL']:null;
 const pool=C.filter(p=>!categories||categories.includes(p.category));
 // Compare des mots entiers pour ne pas confondre HOT 70 et HOT 700, A06 et A100C.
 const candidates=[];
 for(const p of pool){
   const pn=norm(p.name).replace(/\b(iphone|google|pixel|jbl)\b/g,m=>m); // conserver le libellé d'origine
   const aliases=[pn];
   if(p.category==='IPHONE')aliases.push(pn.replace(/^iphone\s*/,''));
   if(p.category==='GOOGLE PIXEL')aliases.push(pn.replace(/^google\s*/,''));
   if(p.category==='JBL & AUDIO')aliases.push(pn.replace(/^jbl\s*/,''));
   if(p.category==='SAMSUNG GALAXY Z FOLD'||p.category==='SAMSUNG GALAXY Z FLIP')aliases.push(pn.replace(/^z\s*/,''));
   for(const a of aliases){
     const aWords=a.replace(/\+/g,' plus ').replace(/[^a-z0-9]+/g,' ').trim();
     const tWords=t.replace(/\+/g,' plus ').replace(/[^a-z0-9]+/g,' ').trim();
     if(!aWords||aWords.length<3)continue;
     const pattern=new RegExp('(?:^|\\s)'+aWords.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/\s+/g,'\\s+')+'(?=$|\\s)');
     if(pattern.test(tWords))candidates.push({p,length:aWords.length,alias:aWords});
   }
 }
 if(candidates.length){
   const max=Math.max(...candidates.map(x=>x.length));
   const strongest=candidates.filter(x=>x.length===max);
   const unique=[...new Map(strongest.map(x=>[x.p.id,x.p])).values()];
   // « Spark 50 » propose aussi « Spark 50 Pro » ; « Camon 50 Pro » propose Pro et Pro Ultra.
   if(unique.length===1){const p=unique[0],base=key(p.name);
     const related=pool.filter(q=>q.category===p.category&&(key(q.name)===base||key(q.name).startsWith(base+'pro')||key(q.name).startsWith(base+'ultra')||key(q.name).startsWith(base+'plus')));
     if(related.length>1&& !/(ultra|\bplus\b|\+)/.test(t))return {products:related,missing};
   }
   return {products:unique,missing};
 }
 // Une marque seule : présenter les références de cette marque, sans inventer de modèle.
 if(categories&&categories.length){const b=norm(input).replace(/\b(salut|bonjour|bonsoir|je|cherche|voulais|voudrais|un|une|des|les|le|la|prix|tarifs|telephones|telephone|modeles|modele|chez|vous|avez|vous|svp|s|il|plait|montrez|moi|tous|toutes|marque|de|du|des|pour|votre|en|stock|combien|coutent|ca|fait|coute|commander|acheter|liste)\b/g,' ').trim();
   if(/^(samsung|galaxy|iphone|apple|pixel|google|tecno|infinix|itel|jbl)$/.test(b))return {products:pool,missing};
 }
 return {products:[],missing};
}
window.ERO7_MODEL_SEARCH={search};
})();
