(()=>{'use strict';
const C=window.ERO7_CATALOGUE||[];
const PHONE='243823892361';
const $=id=>document.getElementById(id);
const msg=$('messages'),suggestions=$('suggestions');
let chosen=null,offer=null,offerRequested=false,awaitingOffer=false,activeForm=null;
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
const compact=s=>norm(s).replace(/[^a-z0-9+]/g,'');
const money=p=>p===null||p===undefined?'Prix à confirmer':`${Number(p).toLocaleString('fr-FR')} $`;
const name=p=>p.category.startsWith('SAMSUNG')?`Samsung Galaxy ${p.name}`:p.category==='IPHONE'?p.name:p.category==='GOOGLE PIXEL'&&!p.name.startsWith('Google')?`Google ${p.name}`:p.category==='TECNO'?`Tecno ${p.name}`:p.category==='INFINIX'?`Infinix ${p.name}`:p.category==='ITEL'?`Itel ${p.name}`:p.name;
const stamp=()=>new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit'}).format(new Date());
const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n};
const scroll=()=>{msg.scrollTop=msg.scrollHeight};
function bubble(text,who='bot'){const b=el('div','bubble '+who,text);b.append(el('div','stamp',stamp()));msg.append(b);scroll();return b}
function quick(buttons){const box=el('div','choices');for(const [label,fn] of buttons){const b=el('button','choice',label);b.type='button';b.addEventListener('click',fn);box.append(b)}msg.append(box);scroll();return box}
function setSuggestions(arr){suggestions.replaceChildren();for(const [label,fn] of arr){const b=el('button','',label);b.type='button';b.addEventListener('click',fn);suggestions.append(b)}}
function say(text){bubble(text,'user');respond(text)}
const allPrice=(p)=>p.options.map(o=>`${o.storage} : ${money(o.price)}`).join(' · ');
function selectionPrice(){return chosen?.product.options[chosen.index].price??null}
function choose(p,index){if(p.options[index].price===null||p.options[index].price===undefined){bubble('⚠️ Le tarif exact de cette variante doit être confirmé par notre équipe. Aucun prix non vérifié ne sera annoncé. Vous pouvez choisir un autre modèle dont le prix est précisé dans la publicité.');return}if(activeForm){activeForm.remove();activeForm=null}chosen={product:p,index};offer=null;offerRequested=false;awaitingOffer=false;const o=p.options[index];bubble(`✅ Vous avez choisi :\n📱 ${name(p)}\n💾 ${o.storage}\n💵 Prix affiché : ${money(o.price)}${isAmbiguous(p,o)?'\n⚠️ Ce prix est indiqué sans variante complète dans la publicité. Notre équipe confirmera les détails.':''}\n\nSouhaitez-vous commander avec livraison, réserver un achat à la boutique ou demander une contre-valeur ?`);quick(p.service?[['🏬 Réserver la pose en boutique',()=>openForm('shop')]]:[
 ['🚚 Livraison à domicile',()=>openForm('delivery')],['🏬 Réservation en boutique',()=>openForm('shop')],['🔄 Contre-valeur',()=>openForm('trade')]
]);setSuggestions([['📍 Adresse',()=>say('Quelle est votre adresse ?')],['📋 Toute la liste',()=>say('Toute la liste')],['✏️ Autre modèle',()=>say('Je veux un autre téléphone')]])}
function isAmbiguous(p,o){return /confirmer|non precise|offre [12]/.test(norm(o.storage))}
function productCard(p){const card=el('div','product');card.append(el('div','product-title',`${p.icon||'📱'} ${name(p)}`));const vars=el('div','variants');p.options.forEach((o,i)=>{const unknown=o.price===null||o.price===undefined;const label=unknown?`${o.storage} · ${o.note||'Prix à confirmer'}`:`${o.storage} · ${money(o.price)} → Choisir`;const b=el('button','variant'+(unknown||isAmbiguous(p,o)?' warn':''),label);b.type='button';b.disabled=unknown;b.title=unknown?'Tarif non confirmé : sélection désactivée':'';if(!unknown)b.addEventListener('click',()=>choose(p,i));vars.append(b)});card.append(vars);return card}
function showProducts(products,title,{all=false}={}){if(!products.length){bubble('Je n’ai pas trouvé ce modèle dans les prix de notre publicité. Vérifiez son nom ou demandez la liste complète.');quick([['📋 Toute la liste',()=>showAll()]]);return}
 const block=el('div','options-block');block.append(el('h3','',title));block.append(el('p','',`Prix repris de notre publicité · ${products.length} modèle(s). Touchez le prix et la capacité qui vous conviennent.`));msg.append(block);
 let offset=0;const page=all?18:30;let previousCat='';const add=()=>{const batch=products.slice(offset,offset+page);for(const p of batch){if(all&&p.category!==previousCat){previousCat=p.category;block.append(el('div','category',p.category))}block.append(productCard(p))}offset+=batch.length;if(offset<products.length){more.textContent=`Afficher les ${Math.min(page,products.length-offset)} modèles suivants (${products.length-offset} restants) ↓`;block.append(more)}else more.remove();scroll()};const more=el('button','morebtn','Afficher la suite');more.type='button';more.addEventListener('click',()=>{more.remove();add()});add();scroll();}
function showAll(){bubble('📋 Voici la liste complète des produits avec les prix et les capacités indiqués dans notre publicité. Faites défiler les choix et sélectionnez directement votre modèle.');showProducts(C,'📋 Tous les modèles et leurs prix',{all:true})}
function modelResult(text){return window.ERO7_MODEL_SEARCH.search(text,C)}
function matchModels(text){return modelResult(text).products}
function address(){bubble('📍 ETS ERO 7 BUSINESS\nAvenue Ipenge N°1, Kinshasa-Gombe.\n🏢 Galerie Dubaï Mall, Local C4.\n📌 Référence : Hôtel Memling, Boulevard du 30 Juin, en face de l’ex-Canon.\n👉 À votre arrivée, demandez « Local C4 » à la sécurité.');quick([['📱 Voir les téléphones',()=>say('Je cherche un téléphone')],['🔄 Contre-valeur',()=>say('Vous faites le troc ?')]])}
function tradeInfo(request=''){bubble('🔄 Oui, nous faisons le troc / contre-valeur. Vous pouvez échanger votre téléphone pour en acheter un autre.\n📍 L’évaluation de votre appareil et le montant à ajouter se déterminent uniquement à notre boutique, Galerie Dubaï Mall, Local C4.\nQuel téléphone souhaitez-vous obtenir ?');const desired=norm(request).split(/pour\s+(?:prendre|acheter|avoir|obtenir)|contre\s+(?:un|une)?/).slice(-1)[0];if(desired&&desired!==norm(request)){const found=matchModels(desired);if(found.length)showProducts(found,'📱 Téléphones souhaités et prix')}quick([['📋 Voir toute la liste',()=>showAll()],['🏬 Préparer une visite pour troc',()=>openForm('trade')]])}
function priceOffer(){if(!chosen){bubble('💬 Quel modèle souhaitez-vous acheter ? Indiquez-le d’abord pour que je vous présente son prix exact et ses capacités.');return}offerRequested=true;awaitingOffer=true;bubble(`Je comprends. Le prix affiché pour ${name(chosen.product)} (${chosen.product.options[chosen.index].storage}) est de ${money(selectionPrice())}.\n💬 Vous pouvez proposer le prix qui correspond à votre budget, en dollars. Notre équipe l’examinera après réception de votre demande finale.\nQuel prix proposez-vous ?`);setSuggestions([['🚚 Commander',()=>openForm('delivery')],['🏬 Réserver',()=>openForm('shop')]])}
function extractOffer(text){const m=norm(text).replace(',','.').match(/(?:^|\s|\$)(\d{2,5})(?:\s*(?:usd|dollars?|\$))?(?:$|\s)/);return m?Number(m[1]):null}
function deliveryInfo(){bubble('🚚 Nous assurons la livraison directe à domicile à Kinshasa. Les frais dépendent de votre adresse et seront confirmés avant validation.\n📦 Hors Kinshasa, vous pouvez passer par un proche à Kinshasa ou choisir une agence d’expédition.\nQuel téléphone souhaitez-vous commander ?')}
function availability(){bubble('📦 Les modèles et prix présentés proviennent de notre publicité. Notre équipe confirmera la disponibilité exacte du modèle choisi avant validation de votre commande. Quel modèle souhaitez-vous ?')}
function photos(){bubble('📸 Les photos réelles ne sont pas intégrées à cette conversation. Si vous avez besoin de photos d’un modèle précis, indiquez-le dans les précisions de votre demande finale : notre équipe vous répondra avant confirmation.')}
function listIntent(t){return /\b(toute?\s+la\s+liste|liste\s+complete|tous\s+les\s+prix|tous\s+les\s+modeles|tout\s+le\s+catalogue|catalogue\s+complet|voir\s+tout|tous\s+vos\s+telephones|toutes\s+les\s+marques|envoyez\s+la\s+liste|liste\s+des\s+prix|liste\s+des\s+telephones)\b/.test(t)||t==='liste'||t==='catalogue'}
function respond(text){const t=norm(text);
 if(awaitingOffer){const n=extractOffer(text);if(n!==null&&n>0){offer=n;awaitingOffer=false;bubble(`🤝 Votre proposition de ${money(n)} est notée. Elle n’est pas encore acceptée : notre équipe décidera après réception de votre demande.\nSouhaitez-vous commander ou réserver ce modèle ?`);quick([['🚚 Commander',()=>openForm('delivery')],['🏬 Réserver',()=>openForm('shop')]]);return}if(!/(annul|autre|adresse|troc|liste|modele)/.test(t)){bubble('💬 Indiquez un montant en dollars, par exemple « 650 $ », ou choisissez une autre démarche.');return}awaitingOffer=false}
 if(listIntent(t)){showAll();return}
 if(/\b(adresse|adress|situe|localisation|local\s*c4|memling|ou\s+etes|ou\s+se\s+trouve|ou\s+est\s+votre|boutique\s+est\s+ou)\b/.test(t)){address();return}
 if(/\b(troc|troque|contre.?valeur|echang|echange|echanger|reprise)\b/.test(t)||/\b(vous\s+faites\s+(aussi\s+)?trop)\b/.test(t)){tradeInfo(text);return}
 if(/\b(trop\s+cher|c.?est\s+cher|cher\s+pour\s+moi|prix\s+eleve|redu[cs]tion|negoci\w*|rabais|remise|dernier\s+prix|moins\s+cher|faire\s+un\s+prix|baisser\s+le\s+prix|propose\s+\d+\s*\$)\b/.test(t)){priceOffer();return}
 if(/\b(livraison|livrez|livrer|expedier|expedition|frais\s+de\s+livraison|quelle\s+ville)\b/.test(t)){if(chosen&&/\b(je\s+veux|je\s+souhaite|commander|commande)\b/.test(t))openForm('delivery');else deliveryInfo();return}
 if(/\b(reserv|passer\s+au\s+shop|acheter\s+au\s+shop|achat\s+sur\s+place)\b/.test(t)){if(chosen)openForm('shop');else{bubble('🏬 Vous pouvez réserver un achat à la boutique. Quel téléphone souhaitez-vous réserver ?');quick([['📋 Liste des modèles',()=>showAll()]])}return}
 if(/\b(photos?|images?|couleurs?)\b/.test(t)&&!/\b(iphone|samsung|pixel|tecno|infinix|itel)\b/.test(t)){photos();return}
 if(/\b(disponib|stock|en\s+vente)\b/.test(t)&&!/\b(s\d+|iphone|pixel|fold|flip)\b/.test(t)){availability();return}
 const result=modelResult(text);const matches=result.products;
 if(result.missing)bubble('⚠️ '+result.missing);
 if(matches.length){if(!result.missing)bubble('💵 Voici les prix exacts indiqués dans notre publicité. Choisissez le modèle et le stockage selon votre budget 👇');showProducts(matches,`📱 ${matches.length} modèle(s) correspondant(s)`);return}
 if(result.missing){bubble('Quel autre modèle souhaitez-vous consulter ?');return}
 if(/\b(?:iphone|samsung|galaxy|tecno|infinix|itel|pixel|google|jbl|fold|flip|note|spark|camon|hot|smart|pop|city|a\d{2,3}|s\d{1,2})\b/.test(t)){bubble('📱 Je ne trouve pas ce modèle exact dans les prix de notre publicité. Pouvez-vous préciser la marque et le modèle complet ? Par exemple : « Samsung S24 Ultra » ou « iPhone 14 Pro ». Aucun prix non communiqué ne sera inventé.');quick([['📋 Toute la liste',()=>showAll()]]);return} 
 if(/\b(prix|combien|cout|tarif)\b/.test(t)){if(chosen){const p=chosen.product;showProducts([p],`💵 ${name(p)} — Tous les stockages`)}else{bubble('📱 Quel téléphone vous intéresse ? Écrivez par exemple « S21 », « S22 » ou « iPhone 14 Pro » et je vous donnerai tous les prix des modèles correspondants.')}return}
 if(/\b(ordinateur|pc|laptop)\b/.test(t)){bubble('💻 Notre publicité annonce aussi des ordinateurs, mais ne fournit pas encore leurs modèles et prix. Je préfère ne pas vous communiquer un tarif non vérifié.');return}
 if(/\b(bonjour|bonsoir|salut|coucou|hello|bjr|slt)\b/.test(t)){bubble('👋🏾 Salut ! Vous souhaitez acheter quel téléphone, s’il vous plaît ?');return}
 if(chosen&&/\b(je\s+veux\s+commander|je\s+commande|passer\s+commande|commander\s+ce\s+telephone|acheter\s+ce\s+telephone)\b/.test(t)){openForm('delivery');return}
 if(chosen&&/\b(je\s+veux\s+reserver|reserver\s+ce\s+telephone)\b/.test(t)){openForm('shop');return}
 if(/\b(acheter|commander|commande|telephone|smartphone|modeles|appareil)\b/.test(t)){bubble('📱 Quel téléphone souhaitez-vous acheter, s’il vous plaît ? Écrivez simplement son modèle (ex. S21 ou iPhone 14 Pro) et je vous présenterai tous les prix.');quick([['📋 Toute la liste',()=>showAll()]]);return}
 bubble('Je peux vous renseigner sur les prix, les modèles, notre adresse, la livraison et le troc / contre-valeur. 😊\nQuel téléphone recherchez-vous, s’il vous plaît ?');quick([['📋 Toute la liste',()=>showAll()],['📍 Adresse',address],['🔄 Troc',tradeInfo]])
}
function field(form,label,id,{required=false,type='text',value='',placeholder='',rows=0}={}){const wrap=el('div','field');const lab=el('label','',label);lab.htmlFor=id;const input=el(rows?'textarea':'input');input.id=id;input.name=id;if(!rows)input.type=type;else input.rows=rows;input.required=required;input.placeholder=placeholder;if(value)input.value=value;wrap.append(lab,input);form.append(wrap);return input}
function line(label,v){return `${label} : ${v||'À confirmer'}`}
function finalMessage(kind,form){
 const p=chosen?.product,o=p?.options[chosen.index],n=Math.max(1,Math.min(99,Number(form.elements.quantite?.value)||1)),price=o?.price??null,total=price===null?null:price*n;
 const title=kind==='delivery'?'🛒 NOUVELLE COMMANDE':kind==='shop'?'🏬 NOUVELLE RÉSERVATION D’ACHAT':'🔄 DEMANDE DE CONTRE-VALEUR';
 const productLabel=p?.category==='JBL & AUDIO'||p?.category==='ACCESSOIRES'||p?.category==='ANTI-CASSE (POSE EN BOUTIQUE)'?'🛍️ Produit':'📱 Téléphone';
 const lines=[title,'',line(productLabel,p?name(p):form.elements.modele_souhaite?.value)];
 if(p){lines.push(line('💾 Stockage / variante',o.storage),line('🎨 Couleur',form.elements.couleur?.value.trim()),line('📦 Quantité',String(n)),'',line('💵 Prix unitaire',money(price)),line('💵 Prix des articles',money(total)));}
 if(kind==='delivery')lines.push('🚚 Frais de livraison : À confirmer');
 if(offerRequested&&offer!==null)lines.push(`🤝 Prix proposé par le client : ${money(offer)} (en attente de validation)`);
 lines.push('',line('👤 Nom',form.elements.nom.value.trim()),line('📞 Numéro',form.elements.telephone.value.trim()));
 if(kind==='delivery')lines.push('',line('📍 Ville',form.elements.ville.value.trim()),line('📍 Commune',form.elements.commune.value.trim()),line('🏠 Adresse',form.elements.adresse.value.trim()));
 if(kind==='shop')lines.push('',line('📅 Date souhaitée',form.elements.date.value),line('🕒 Heure souhaitée',form.elements.heure.value),'📍 Achat au shop : Galerie Dubaï Mall, Local C4');
 if(kind==='trade'){
  lines.push('',line('📱 Téléphone à échanger',form.elements.ancien.value.trim()),line('📝 État du téléphone',form.elements.etat.value.trim()));
  if(form.elements.date?.value)lines.push(line('📅 Date souhaitée',form.elements.date.value));
  if(form.elements.heure?.value)lines.push(line('🕒 Heure souhaitée',form.elements.heure.value));
  lines.push('📍 Évaluation et contre-valeur uniquement au shop, Local C4');
 }
 if(form.elements.note?.value.trim())lines.push('',line('📝 Précisions',form.elements.note.value.trim()));
 lines.push('',kind==='trade'?'💰 Montant à ajouter : À déterminer après évaluation en boutique':line('💰 Total à payer',total===null?'À confirmer':`${money(total)}${kind==='delivery'?' + frais de livraison à confirmer':''}`),'','Merci de confirmer la disponibilité et les conditions.','Merci.');
 return lines.join('\n');
}
function openForm(kind){if(chosen?.product.service&&kind!=='shop'){bubble('🛡️ La pose d’anti-casse se fait uniquement à notre établissement. Choisissez une réservation pour venir à la boutique.');kind='shop'}if(kind!=='trade'&&!chosen){bubble('📱 Choisissez d’abord le téléphone et son stockage. Je préparerai ensuite votre commande ou votre réservation.');quick([['📋 Toute la liste',()=>showAll()]]);return}
 if(activeForm){activeForm.remove();activeForm=null}
 const card=el('div','form-card');const title=kind==='delivery'?'🛒 Finaliser votre commande':kind==='shop'?'🏬 Réserver votre achat':'🔄 Préparer votre contre-valeur';card.append(el('h3','',title));
 card.append(el('p','',kind==='trade'?'L’évaluation de votre ancien téléphone et le montant à ajouter se font uniquement sur place.':'Remplissez vos coordonnées. Seul ce récapitulatif final sera préparé pour WhatsApp.'));
 const form=el('form');form.noValidate=false;
 if(!chosen&&kind==='trade')field(form,'📱 Téléphone que vous souhaitez obtenir','modele_souhaite',{required:true,placeholder:'Ex. Samsung S21 Ultra 256GB'});
 field(form,'👤 Votre nom','nom',{required:true,placeholder:'Nom du client'});
 field(form,'📞 Votre numéro','telephone',{required:true,type:'tel',placeholder:'Ex. 082...'});
 if(kind==='delivery'){
  const row=el('div','row2');form.append(row);field(row,'📍 Ville','ville',{required:true,value:'Kinshasa'});field(row,'📍 Commune','commune',{required:true,placeholder:'Ex. Gombe'});
  field(form,'🏠 Adresse de livraison','adresse',{required:true,rows:2,placeholder:'Avenue, numéro, référence'});
  card.append(el('p','', '🚚 Livraison directe à Kinshasa. Les frais seront confirmés selon l’adresse. Hors Kinshasa, l’expédition doit être organisée avec notre équipe.'));
 }
 if(kind==='shop'){const row=el('div','row2');form.append(row);const d=field(row,'📅 Date de passage','date',{type:'date',required:true});d.min=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);field(row,'🕒 Heure souhaitée','heure',{type:'time',required:true})}
 if(kind==='trade'){field(form,'📱 Téléphone à échanger','ancien',{required:true,placeholder:'Modèle et capacité'});field(form,'📝 État de votre téléphone','etat',{required:true,rows:2,placeholder:'État, défauts éventuels...'});const row=el('div','row2');form.append(row);field(row,'📅 Date de passage (facultatif)','date',{type:'date'});field(row,'🕒 Heure (facultatif)','heure',{type:'time'})}
 if(kind!=='trade'||chosen){const row=el('div','row2');form.append(row);field(row,'🎨 Couleur souhaitée','couleur',{placeholder:'Ex. Noir'});field(row,'📦 Quantité','quantite',{required:true,type:'number',value:'1'})}
 field(form,'📝 Précisions (facultatif)','note',{rows:2,placeholder:'Question particulière ou information utile'});
 const price=selectionPrice();if(chosen){card.append(el('div','total',`📱 ${name(chosen.product)} · ${chosen.product.options[chosen.index].storage}\n💵 Prix affiché : ${money(price)}${offerRequested&&offer!==null?'\n🤝 Proposition : '+money(offer)+' (à valider)':''}`))}
 const send=el('button','submit','📲 Envoyer ma demande finale sur WhatsApp');send.type='submit';form.append(send);form.append(el('div','small','WhatsApp s’ouvrira avec votre demande préremplie. Appuyez ensuite sur « Envoyer » pour nous la transmettre.'));card.append(form);msg.append(card);activeForm=card;
 form.addEventListener('submit',ev=>{ev.preventDefault();if(!form.reportValidity())return;if(kind==='delivery'&&norm(form.elements.ville.value)!=='kinshasa'){bubble('📦 Pour une autre ville, nous ne proposons pas de livraison directe. Vous pouvez organiser l’expédition via une agence ou un proche à Kinshasa. Votre demande sera soumise à confirmation.')}const text=finalMessage(kind,form);const url=`https://wa.me/${PHONE}?text=${encodeURIComponent(text)}`;window.location.href=url});scroll();
 setSuggestions([['📍 Adresse',()=>say('Votre adresse ?')],['📋 Liste complète',()=>showAll()]]);
}
$('chatForm').addEventListener('submit',e=>{e.preventDefault();const text=$('userInput').value.trim();if(!text)return;$('userInput').value='';say(text)});
$('menuBtn').addEventListener('click',()=>{$('infoPanel').hidden=false});$('closeInfo').addEventListener('click',()=>{$('infoPanel').hidden=true});$('infoPanel').addEventListener('click',e=>{if(e.target===$('infoPanel'))$('infoPanel').hidden=true});
bubble('Salut 👋🏾 Vous souhaitez acheter quel téléphone, s’il vous plaît ?');
})();
