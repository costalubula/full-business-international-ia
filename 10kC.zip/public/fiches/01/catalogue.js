/* Catalogue des prix EXCLUSIVEMENT issus de la publicité fournie par le propriétaire, 14/10/2026. Les variantes ambiguës sont bloquées. */
window.ERO7_CATALOGUE = [
  {
    "id": 1,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 2",
    "options": [
      {
        "storage": "256GB",
        "price": 430
      }
    ],
    "service": false
  },
  {
    "id": 2,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 3",
    "options": [
      {
        "storage": "256GB",
        "price": 455
      },
      {
        "storage": "512GB",
        "price": 505
      }
    ],
    "service": false
  },
  {
    "id": 3,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 4",
    "options": [
      {
        "storage": "256GB",
        "price": 585
      },
      {
        "storage": "512GB",
        "price": 600
      }
    ],
    "service": false
  },
  {
    "id": 4,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 5",
    "options": [
      {
        "storage": "256GB",
        "price": 695
      },
      {
        "storage": "512GB",
        "price": 730
      }
    ],
    "service": false
  },
  {
    "id": 5,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 6",
    "options": [
      {
        "storage": "256GB",
        "price": 970
      },
      {
        "storage": "512GB",
        "price": 1070
      }
    ],
    "service": false
  },
  {
    "id": 6,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 7",
    "options": [
      {
        "storage": "256GB",
        "price": 1420
      },
      {
        "storage": "512GB",
        "price": 1570
      }
    ],
    "service": false
  },
  {
    "id": 7,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 8",
    "options": [
      {
        "storage": "256GB",
        "price": 1770
      }
    ],
    "service": false
  },
  {
    "id": 8,
    "category": "SAMSUNG GALAXY Z FOLD",
    "icon": "📱",
    "name": "Z Fold 8 Ultra",
    "options": [
      {
        "storage": "256GB",
        "price": 1820
      },
      {
        "storage": "512GB",
        "price": 1970
      }
    ],
    "service": false
  },
  {
    "id": 9,
    "category": "SAMSUNG GALAXY Z FLIP",
    "icon": "📱",
    "name": "Z Flip 3",
    "options": [
      {
        "storage": "128GB",
        "price": 235
      },
      {
        "storage": "256GB",
        "price": 255
      }
    ],
    "service": false
  },
  {
    "id": 10,
    "category": "SAMSUNG GALAXY Z FLIP",
    "icon": "📱",
    "name": "Z Flip 4",
    "options": [
      {
        "storage": "128GB",
        "price": 305
      },
      {
        "storage": "256GB",
        "price": 325
      }
    ],
    "service": false
  },
  {
    "id": 11,
    "category": "SAMSUNG GALAXY Z FLIP",
    "icon": "📱",
    "name": "Z Flip 5",
    "options": [
      {
        "storage": "256GB",
        "price": 410
      },
      {
        "storage": "512GB",
        "price": 430
      }
    ],
    "service": false
  },
  {
    "id": 12,
    "category": "SAMSUNG GALAXY Z FLIP",
    "icon": "📱",
    "name": "Z Flip 6",
    "options": [
      {
        "storage": "256GB",
        "price": 490
      },
      {
        "storage": "512GB",
        "price": 560
      }
    ],
    "service": false
  },
  {
    "id": 13,
    "category": "SAMSUNG GALAXY Z FLIP",
    "icon": "📱",
    "name": "Z Flip 7",
    "options": [
      {
        "storage": "256GB",
        "price": 700
      },
      {
        "storage": "512GB",
        "price": 720
      }
    ],
    "service": false
  },
  {
    "id": 14,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S9",
    "options": [
      {
        "storage": "64GB",
        "price": 140
      }
    ],
    "service": false
  },
  {
    "id": 15,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S9+",
    "options": [
      {
        "storage": "64GB",
        "price": 165
      }
    ],
    "service": false
  },
  {
    "id": 16,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S10",
    "options": [
      {
        "storage": "128GB",
        "price": 225
      }
    ],
    "service": false
  },
  {
    "id": 17,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S10+",
    "options": [
      {
        "storage": "128GB",
        "price": 265
      }
    ],
    "service": false
  },
  {
    "id": 18,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S20",
    "options": [
      {
        "storage": "128GB",
        "price": 255
      }
    ],
    "service": false
  },
  {
    "id": 19,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S20+",
    "options": [
      {
        "storage": "128GB",
        "price": 275
      }
    ],
    "service": false
  },
  {
    "id": 20,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S20 Ultra",
    "options": [
      {
        "storage": "128GB",
        "price": 315
      }
    ],
    "service": false
  },
  {
    "id": 21,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S21",
    "options": [
      {
        "storage": "128GB",
        "price": 285
      },
      {
        "storage": "256GB",
        "price": 305
      }
    ],
    "service": false
  },
  {
    "id": 22,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S21+",
    "options": [
      {
        "storage": "128GB",
        "price": 320
      },
      {
        "storage": "256GB",
        "price": 340
      }
    ],
    "service": false
  },
  {
    "id": 23,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S21 Ultra",
    "options": [
      {
        "storage": "128GB",
        "price": 370
      },
      {
        "storage": "256GB",
        "price": 390
      }
    ],
    "service": false
  },
  {
    "id": 24,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S22",
    "options": [
      {
        "storage": "128GB",
        "price": 400
      },
      {
        "storage": "256GB",
        "price": 430
      }
    ],
    "service": false
  },
  {
    "id": 25,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S22+",
    "options": [
      {
        "storage": "128GB",
        "price": 460
      },
      {
        "storage": "256GB",
        "price": 490
      }
    ],
    "service": false
  },
  {
    "id": 26,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S22 Ultra",
    "options": [
      {
        "storage": "128GB",
        "price": 510
      },
      {
        "storage": "256GB",
        "price": 550
      }
    ],
    "service": false
  },
  {
    "id": 27,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S23",
    "options": [
      {
        "storage": "128GB",
        "price": 560
      },
      {
        "storage": "256GB",
        "price": 610
      }
    ],
    "service": false
  },
  {
    "id": 28,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S23+",
    "options": [
      {
        "storage": "128GB",
        "price": 610
      },
      {
        "storage": "256GB",
        "price": 650
      }
    ],
    "service": false
  },
  {
    "id": 29,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S23 Ultra",
    "options": [
      {
        "storage": "128GB",
        "price": 690
      },
      {
        "storage": "256GB",
        "price": 730
      }
    ],
    "service": false
  },
  {
    "id": 30,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S24",
    "options": [
      {
        "storage": "256GB",
        "price": 800
      }
    ],
    "service": false
  },
  {
    "id": 31,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S24+",
    "options": [
      {
        "storage": "256GB",
        "price": 820
      }
    ],
    "service": false
  },
  {
    "id": 32,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S24 Ultra",
    "options": [
      {
        "storage": "256GB",
        "price": 850
      },
      {
        "storage": "512GB",
        "price": 870
      }
    ],
    "service": false
  },
  {
    "id": 33,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S25 Ultra",
    "options": [
      {
        "storage": "256GB",
        "price": 990
      },
      {
        "storage": "512GB",
        "price": 1020
      }
    ],
    "service": false
  },
  {
    "id": 34,
    "category": "SAMSUNG GALAXY S",
    "icon": "📱",
    "name": "S26 Ultra",
    "options": [
      {
        "storage": "256GB",
        "price": 1370
      },
      {
        "storage": "512GB",
        "price": 1500
      }
    ],
    "service": false
  },
  {
    "id": 35,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 8",
    "options": [
      {
        "storage": "64GB",
        "price": 175
      }
    ],
    "service": false
  },
  {
    "id": 36,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 9",
    "options": [
      {
        "storage": "128GB",
        "price": 200
      }
    ],
    "service": false
  },
  {
    "id": 37,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 10 Simple",
    "options": [
      {
        "storage": "256GB",
        "price": 270
      }
    ],
    "service": false
  },
  {
    "id": 38,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 10+",
    "options": [
      {
        "storage": "256GB",
        "price": 290
      }
    ],
    "service": false
  },
  {
    "id": 39,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 20 Simple",
    "options": [
      {
        "storage": "128GB",
        "price": 330
      },
      {
        "storage": "256GB",
        "price": 360
      }
    ],
    "service": false
  },
  {
    "id": 40,
    "category": "SAMSUNG GALAXY NOTE",
    "icon": "📱",
    "name": "Note 20 Ultra",
    "options": [
      {
        "storage": "128GB",
        "price": 390
      },
      {
        "storage": "256GB",
        "price": 410
      }
    ],
    "service": false
  },
  {
    "id": 41,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A06",
    "options": [
      {
        "storage": "128GB",
        "price": 155
      }
    ],
    "service": false
  },
  {
    "id": 42,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A16",
    "options": [
      {
        "storage": "128GB",
        "price": 185
      }
    ],
    "service": false
  },
  {
    "id": 43,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A17",
    "options": [
      {
        "storage": "128GB",
        "price": 205
      }
    ],
    "service": false
  },
  {
    "id": 44,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A25",
    "options": [
      {
        "storage": "128GB",
        "price": 275
      }
    ],
    "service": false
  },
  {
    "id": 45,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A33",
    "options": [
      {
        "storage": "128GB",
        "price": 265
      }
    ],
    "service": false
  },
  {
    "id": 46,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A34",
    "options": [
      {
        "storage": "128GB",
        "price": 275
      }
    ],
    "service": false
  },
  {
    "id": 47,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A35",
    "options": [
      {
        "storage": "128GB",
        "price": 360
      }
    ],
    "service": false
  },
  {
    "id": 48,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A54",
    "options": [
      {
        "storage": "256GB",
        "price": 460
      }
    ],
    "service": false
  },
  {
    "id": 49,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A55",
    "options": [
      {
        "storage": "256GB",
        "price": 480
      }
    ],
    "service": false
  },
  {
    "id": 50,
    "category": "SAMSUNG GALAXY A",
    "icon": "📱",
    "name": "A57",
    "options": [
      {
        "storage": "Non précisé",
        "price": 570
      }
    ],
    "service": false
  },
  {
    "id": 51,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone XR",
    "options": [
      {
        "storage": "64GB",
        "price": 190
      },
      {
        "storage": "128GB",
        "price": 210
      }
    ],
    "service": false
  },
  {
    "id": 52,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 11",
    "options": [
      {
        "storage": "64GB",
        "price": 245
      },
      {
        "storage": "128GB",
        "price": 265
      }
    ],
    "service": false
  },
  {
    "id": 53,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 11 Pro",
    "options": [
      {
        "storage": "64GB",
        "price": 300
      },
      {
        "storage": "256GB",
        "price": 335
      }
    ],
    "service": false
  },
  {
    "id": 54,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 11 Pro Max",
    "options": [
      {
        "storage": "64GB",
        "price": 340
      },
      {
        "storage": "256GB",
        "price": 380
      }
    ],
    "service": false
  },
  {
    "id": 55,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 12",
    "options": [
      {
        "storage": "64GB",
        "price": 310
      },
      {
        "storage": "128GB",
        "price": 360
      }
    ],
    "service": false
  },
  {
    "id": 56,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 12 Pro",
    "options": [
      {
        "storage": "128GB",
        "price": 360
      },
      {
        "storage": "256GB",
        "price": 390
      }
    ],
    "service": false
  },
  {
    "id": 57,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 12 Pro Max",
    "options": [
      {
        "storage": "128GB",
        "price": 430
      },
      {
        "storage": "256GB",
        "price": 460
      }
    ],
    "service": false
  },
  {
    "id": 58,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 13",
    "options": [
      {
        "storage": "128GB",
        "price": 390
      },
      {
        "storage": "256GB",
        "price": 410
      }
    ],
    "service": false
  },
  {
    "id": 59,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 13 Pro",
    "options": [
      {
        "storage": "128GB",
        "price": 485
      },
      {
        "storage": "256GB",
        "price": 510
      }
    ],
    "service": false
  },
  {
    "id": 60,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 13 Pro Max",
    "options": [
      {
        "storage": "128GB",
        "price": 590
      },
      {
        "storage": "256GB",
        "price": 610
      }
    ],
    "service": false
  },
  {
    "id": 61,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 14 Pro",
    "options": [
      {
        "storage": "128GB",
        "price": 590
      },
      {
        "storage": "256GB",
        "price": 610
      }
    ],
    "service": false
  },
  {
    "id": 62,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 14 Pro Max",
    "options": [
      {
        "storage": "128GB",
        "price": 700
      },
      {
        "storage": "256GB",
        "price": 720
      }
    ],
    "service": false
  },
  {
    "id": 63,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 15 Pro",
    "options": [
      {
        "storage": "128GB",
        "price": 660
      },
      {
        "storage": "256GB",
        "price": 700
      }
    ],
    "service": false
  },
  {
    "id": 64,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 15 Pro Max",
    "options": [
      {
        "storage": "256GB",
        "price": 820
      },
      {
        "storage": "512GB",
        "price": 870
      }
    ],
    "service": false
  },
  {
    "id": 65,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 16",
    "options": [
      {
        "storage": "256GB",
        "price": 870
      }
    ],
    "service": false
  },
  {
    "id": 66,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 16 Plus",
    "options": [
      {
        "storage": "256GB",
        "price": 900
      }
    ],
    "service": false
  },
  {
    "id": 67,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 16 Pro",
    "options": [
      {
        "storage": "256GB",
        "price": 1000
      }
    ],
    "service": false
  },
  {
    "id": 68,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 16 Pro Max",
    "options": [
      {
        "storage": "256GB",
        "price": 1170
      }
    ],
    "service": false
  },
  {
    "id": 69,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 17 Pro Max",
    "options": [
      {
        "storage": "256GB",
        "price": 1620
      }
    ],
    "service": false
  },
  {
    "id": 70,
    "category": "IPHONE",
    "icon": "🍎",
    "name": "iPhone 18 Pro Max",
    "options": [
      {
        "storage": "256GB",
        "price": 2470
      }
    ],
    "service": false
  },
  {
    "id": 71,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 6",
    "options": [
      {
        "storage": "Non précisé",
        "price": 285
      }
    ],
    "service": false
  },
  {
    "id": 72,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 6 Pro",
    "options": [
      {
        "storage": "256GB",
        "price": 350
      }
    ],
    "service": false
  },
  {
    "id": 73,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 7",
    "options": [
      {
        "storage": "Non précisé",
        "price": 295
      }
    ],
    "service": false
  },
  {
    "id": 74,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 7 Pro",
    "options": [
      {
        "storage": "Capacité à confirmer",
        "price": null,
        "note": "Tarif ou stockage ambigu dans la publicité : confirmation nécessaire avant toute commande."
      },
      {
        "storage": "256GB",
        "price": 360
      }
    ],
    "service": false
  },
  {
    "id": 75,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 8",
    "options": [
      {
        "storage": "Non précisé",
        "price": 380
      }
    ],
    "service": false
  },
  {
    "id": 76,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 8 Pro",
    "options": [
      {
        "storage": "Non précisé",
        "price": 510
      }
    ],
    "service": false
  },
  {
    "id": 77,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 9",
    "options": [
      {
        "storage": "Capacité à confirmer",
        "price": null,
        "note": "Tarif ou stockage ambigu dans la publicité : confirmation nécessaire avant toute commande."
      },
      {
        "storage": "128GB",
        "price": 670
      }
    ],
    "service": false
  },
  {
    "id": 78,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 9 Pro",
    "options": [
      {
        "storage": "256GB",
        "price": 870
      }
    ],
    "service": false
  },
  {
    "id": 79,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 9 Pro XL",
    "options": [
      {
        "storage": "Capacité à confirmer",
        "price": null,
        "note": "Tarif ou stockage ambigu dans la publicité : confirmation nécessaire avant toute commande."
      },
      {
        "storage": "256GB",
        "price": 900
      }
    ],
    "service": false
  },
  {
    "id": 80,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel 9 Pro Fold",
    "options": [
      {
        "storage": "Non précisé",
        "price": 1120
      }
    ],
    "service": false
  },
  {
    "id": 81,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Pixel Fold",
    "options": [
      {
        "storage": "Non précisé",
        "price": 490
      }
    ],
    "service": false
  },
  {
    "id": 82,
    "category": "GOOGLE PIXEL",
    "icon": "🟢",
    "name": "Google Pixel 10 Pro Fold",
    "options": [
      {
        "storage": "256GB",
        "price": 1670
      }
    ],
    "service": false
  },
  {
    "id": 83,
    "category": "TABLETTES SAMSUNG",
    "icon": "💻",
    "name": "Tab A11+ 5G",
    "options": [
      {
        "storage": "7GB/128GB",
        "price": 400
      }
    ],
    "service": false
  },
  {
    "id": 84,
    "category": "TABLETTES SAMSUNG",
    "icon": "💻",
    "name": "Tab 11",
    "options": [
      {
        "storage": "64GB",
        "price": 215
      },
      {
        "storage": "128GB",
        "price": 255
      }
    ],
    "service": false
  },
  {
    "id": 85,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Boombox X4",
    "options": [
      {
        "storage": "Offre 1 (à confirmer)",
        "price": null,
        "note": "Tarif ou stockage ambigu dans la publicité : confirmation nécessaire avant toute commande."
      },
      {
        "storage": "Offre 2 (à confirmer)",
        "price": null,
        "note": "Tarif ou stockage ambigu dans la publicité : confirmation nécessaire avant toute commande."
      }
    ],
    "service": false
  },
  {
    "id": 86,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Boombox X3",
    "options": [
      {
        "storage": "Non précisé",
        "price": 550
      }
    ],
    "service": false
  },
  {
    "id": 87,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Charge 6",
    "options": [
      {
        "storage": "Non précisé",
        "price": 270
      }
    ],
    "service": false
  },
  {
    "id": 88,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Charge 5",
    "options": [
      {
        "storage": "Non précisé",
        "price": 220
      }
    ],
    "service": false
  },
  {
    "id": 89,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Clip 5",
    "options": [
      {
        "storage": "Non précisé",
        "price": 100
      }
    ],
    "service": false
  },
  {
    "id": 90,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Flip 7",
    "options": [
      {
        "storage": "Non précisé",
        "price": 210
      }
    ],
    "service": false
  },
  {
    "id": 91,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL GO 4",
    "options": [
      {
        "storage": "Non précisé",
        "price": 70
      }
    ],
    "service": false
  },
  {
    "id": 92,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL T530",
    "options": [
      {
        "storage": "Non précisé",
        "price": 85
      }
    ],
    "service": false
  },
  {
    "id": 93,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL 720",
    "options": [
      {
        "storage": "Non précisé",
        "price": 100
      }
    ],
    "service": false
  },
  {
    "id": 94,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "JBL Vibe Beam",
    "options": [
      {
        "storage": "Non précisé",
        "price": 100
      }
    ],
    "service": false
  },
  {
    "id": 95,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "Buds 3",
    "options": [
      {
        "storage": "Non précisé",
        "price": 150
      }
    ],
    "service": false
  },
  {
    "id": 96,
    "category": "JBL & AUDIO",
    "icon": "🎧",
    "name": "AirPods Max",
    "options": [
      {
        "storage": "Non précisé",
        "price": 250
      }
    ],
    "service": false
  },
  {
    "id": 97,
    "category": "TECNO",
    "icon": "🔵",
    "name": "POP 20",
    "options": [
      {
        "storage": "64GB",
        "price": 125
      },
      {
        "storage": "128GB",
        "price": 140
      }
    ],
    "service": false
  },
  {
    "id": 98,
    "category": "TECNO",
    "icon": "🔵",
    "name": "SPARK 50",
    "options": [
      {
        "storage": "128GB",
        "price": 170
      },
      {
        "storage": "256GB",
        "price": 200
      }
    ],
    "service": false
  },
  {
    "id": 99,
    "category": "TECNO",
    "icon": "🔵",
    "name": "SPARK 50 PRO",
    "options": [
      {
        "storage": "256GB",
        "price": 235
      }
    ],
    "service": false
  },
  {
    "id": 100,
    "category": "TECNO",
    "icon": "🔵",
    "name": "CAMON 50",
    "options": [
      {
        "storage": "256GB",
        "price": 300
      }
    ],
    "service": false
  },
  {
    "id": 101,
    "category": "TECNO",
    "icon": "🔵",
    "name": "CAMON 50 PRO",
    "options": [
      {
        "storage": "256GB",
        "price": 370
      }
    ],
    "service": false
  },
  {
    "id": 102,
    "category": "TECNO",
    "icon": "🔵",
    "name": "CAMON 50 PRO ULTRA",
    "options": [
      {
        "storage": "512GB",
        "price": 500
      }
    ],
    "service": false
  },
  {
    "id": 103,
    "category": "TECNO",
    "icon": "🔵",
    "name": "CAMON SLIM",
    "options": [
      {
        "storage": "256GB",
        "price": 370
      }
    ],
    "service": false
  },
  {
    "id": 104,
    "category": "INFINIX",
    "icon": "🟠",
    "name": "SMART 20",
    "options": [
      {
        "storage": "64GB",
        "price": 125
      },
      {
        "storage": "128GB",
        "price": 145
      }
    ],
    "service": false
  },
  {
    "id": 105,
    "category": "INFINIX",
    "icon": "🟠",
    "name": "HOT 60i",
    "options": [
      {
        "storage": "128GB",
        "price": 130
      }
    ],
    "service": false
  },
  {
    "id": 106,
    "category": "INFINIX",
    "icon": "🟠",
    "name": "HOT 70",
    "options": [
      {
        "storage": "128GB",
        "price": 165
      },
      {
        "storage": "256GB",
        "price": 235
      }
    ],
    "service": false
  },
  {
    "id": 107,
    "category": "INFINIX",
    "icon": "🟠",
    "name": "NOTE EDGE",
    "options": [
      {
        "storage": "256GB",
        "price": 315
      }
    ],
    "service": false
  },
  {
    "id": 108,
    "category": "INFINIX",
    "icon": "🟠",
    "name": "NOTE 60",
    "options": [
      {
        "storage": "256GB",
        "price": 405
      }
    ],
    "service": false
  },
  {
    "id": 109,
    "category": "ITEL",
    "icon": "🟢",
    "name": "A06",
    "options": [
      {
        "storage": "64GB",
        "price": 85
      }
    ],
    "service": false
  },
  {
    "id": 110,
    "category": "ITEL",
    "icon": "🟢",
    "name": "A100C",
    "options": [
      {
        "storage": "64GB",
        "price": 95
      }
    ],
    "service": false
  },
  {
    "id": 111,
    "category": "ITEL",
    "icon": "🟢",
    "name": "A200",
    "options": [
      {
        "storage": "128GB",
        "price": 115
      }
    ],
    "service": false
  },
  {
    "id": 112,
    "category": "ITEL",
    "icon": "🟢",
    "name": "A200+",
    "options": [
      {
        "storage": "128GB",
        "price": 120
      }
    ],
    "service": false
  },
  {
    "id": 113,
    "category": "ITEL",
    "icon": "🟢",
    "name": "CITY 200",
    "options": [
      {
        "storage": "128GB",
        "price": 135
      }
    ],
    "service": false
  },
  {
    "id": 114,
    "category": "ITEL",
    "icon": "🟢",
    "name": "CITY 200S",
    "options": [
      {
        "storage": "128GB",
        "price": 145
      }
    ],
    "service": false
  },
  {
    "id": 115,
    "category": "ITEL",
    "icon": "🟢",
    "name": "POWER 80",
    "options": [
      {
        "storage": "128GB",
        "price": 155
      }
    ],
    "service": false
  },
  {
    "id": 116,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Pochette magnétique Samsung — Série S",
    "options": [
      {
        "storage": "Prix à confirmer",
        "price": null
      }
    ],
    "service": false
  },
  {
    "id": 117,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Pochette magnétique Samsung — Série Note",
    "options": [
      {
        "storage": "Prix à confirmer",
        "price": null
      }
    ],
    "service": false
  },
  {
    "id": 118,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Pochette magnétique Samsung — Série Z Fold",
    "options": [
      {
        "storage": "Prix à confirmer",
        "price": null
      }
    ],
    "service": false
  },
  {
    "id": 119,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Pochette magnétique Samsung — Série A",
    "options": [
      {
        "storage": "Prix à confirmer",
        "price": null
      }
    ],
    "service": false
  },
  {
    "id": 120,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Pochette batterie iPhone 6 à 16 Pro Max",
    "options": [
      {
        "storage": "Prix à confirmer",
        "price": null
      }
    ],
    "service": false
  },
  {
    "id": 121,
    "category": "ACCESSOIRES",
    "icon": "🧲",
    "name": "Protection caméra iPhone & Samsung",
    "options": [
      {
        "storage": "À partir de",
        "price": null,
        "note": "À partir de 5 $ selon la publicité ; tarif exact à confirmer."
      }
    ],
    "service": false
  },
  {
    "id": 122,
    "category": "ANTI-CASSE (POSE EN BOUTIQUE)",
    "icon": "🛡️",
    "name": "Anti-casse vue claire",
    "options": [
      {
        "storage": "Pose en boutique",
        "price": 5
      }
    ],
    "service": true
  },
  {
    "id": 123,
    "category": "ANTI-CASSE (POSE EN BOUTIQUE)",
    "icon": "🛡️",
    "name": "Anti-casse Privacy",
    "options": [
      {
        "storage": "Pose en boutique",
        "price": 10
      }
    ],
    "service": true
  }
];
